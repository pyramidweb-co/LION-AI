# Lion AI Platform - Product Requirements Document

## Original Problem Statement
Build a private, invite-only AI platform called "Lion AI" inspired by Emergent AI. The platform allows users to generate full-stack web applications using natural language.

## Core Features Implemented

### 1. Authentication System
- **Email + 4-digit PIN system** (no passwords for regular users)
- Whitelist-based access control
- Admin can add/remove emails from whitelist
- PIN hashed with bcrypt
- Rate limiting on PIN attempts (5 attempts, then 5-minute lockout)
- Admin email: `petracom2313@gmail.com`

### 2. Chat System
- User-specific chats (strict data isolation)
- Chat creation, deletion, rename
- Search functionality
- Infinite scroll
- Real-time AI responses

### 3. AI Integration
- **Primary**: Google AI (Gemini 2.0 Flash)
- **Fallback**: Emergent LLM (Claude via LiteLLM)
- Automatic failover on rate limits
- Exponential backoff retry logic
- Real error messages (no fake "high demand" errors)

### 4. Feature Toggles (Session-Persistent)
- **Lightning Fast**: Concise responses, lower temperature
- **Full Code**: Complete projects with all files
- **Database**: Auto-includes MongoDB schemas
- **Secure**: Security best practices
- **Ultra Mode**: Deep reasoning for complex tasks

### 5. Admin Panel
- Whitelist management (add/remove emails)
- User management (view/delete users)
- Platform statistics
- Admin action logs

### 6. Additional Features
- Voice input (Web Speech API)
- Unified attachment system (images + files)
- Code export as ZIP
- Live code preview panel
- Unlimited credits (no artificial limits)

## Tech Stack
- **Frontend**: React, Tailwind CSS, Shadcn/UI
- **Backend**: FastAPI (Python)
- **Database**: MongoDB
- **AI**: Google AI (Gemini) + Emergent LLM (Claude fallback)

## Database Collections
- `users`: id, email, hashed_pin, is_admin, session_token, etc.
- `whitelist`: email, added_by, added_at
- `chats`: id, title, user_id, createdAt
- `messages`: id, chat_id, role, content, timestamp
- `projects`: id, name, user_id, files, etc.
- `admin_logs`: action, admin_email, details, timestamp

## API Endpoints

### Authentication
- `POST /api/auth/check-email` - Check whitelist status
- `POST /api/auth/register` - Create account with PIN
- `POST /api/auth/login` - Login with email + PIN

### Admin
- `GET /api/admin/whitelist` - Get whitelist
- `POST /api/admin/whitelist/add` - Add to whitelist
- `POST /api/admin/whitelist/remove` - Remove from whitelist
- `GET /api/admin/users` - Get all users
- `DELETE /api/admin/users/{id}` - Delete user
- `GET /api/admin/stats` - Platform statistics
- `GET /api/admin/logs` - Admin action logs

### Chats
- `GET /api/chats` - Get user's chats
- `POST /api/chats` - Create chat
- `DELETE /api/chats/{id}` - Delete chat
- `GET /api/chats/{id}/messages` - Get messages
- `POST /api/chats/{id}/messages` - Send message
- `GET /api/chats/{id}/export` - Export as ZIP

### Projects
- `GET /api/projects` - Get user's projects
- `POST /api/projects` - Create project
- `PUT /api/projects/{id}/files` - Update file
- `GET /api/projects/{id}/export` - Export as ZIP

## Status: ✅ MVP Complete

### What's Working
- [x] Email + PIN authentication
- [x] Whitelist-based access control
- [x] User-specific chat isolation
- [x] AI code generation with fallback
- [x] Feature toggles (Lightning Fast, Full Code, Database, Secure, Ultra)
- [x] Voice input
- [x] File attachments
- [x] Code export
- [x] Admin panel
- [x] Unlimited credits (truly unlimited, no artificial limits)

### Known Limitations
- Google AI API key has rate limits (falls back to Emergent LLM)
- Project workspace is basic (file storage, not full IDE)
- No streaming responses yet (planned enhancement)

## Future Enhancements (P2)
- [ ] Streaming AI responses
- [ ] Full project workspace with virtual file system
- [ ] Live iframe preview for multi-file projects
- [ ] Console/runtime error capture
- [ ] Code diff view
- [ ] Undo changes functionality

## Credentials
- Admin Email: `petracom2313@gmail.com`
- Test PIN: `1111` (or create your own)

---
Last Updated: February 26, 2026
