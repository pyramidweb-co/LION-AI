import React, { useState, useEffect } from 'react';
import "./App.css";
import LoginPage from './components/auth/LoginPage';
import Dashboard from './components/dashboard/Dashboard';
import LionLogo from './components/icons/LionLogo';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [userInfo, setUserInfo] = useState(null);

  useEffect(() => {
    const savedAuth = localStorage.getItem('lion_auth');
    if (savedAuth) {
      try {
        const parsed = JSON.parse(savedAuth);
        setUserInfo(parsed);
        setIsAuthenticated(true);
      } catch (e) {
        localStorage.removeItem('lion_auth');
      }
    }
    setIsLoading(false);
  }, []);

  const handleLogin = (loginData) => {
    localStorage.setItem('lion_auth', JSON.stringify(loginData));
    setUserInfo(loginData);
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    localStorage.removeItem('lion_auth');
    setUserInfo(null);
    setIsAuthenticated(false);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen matrix-bg flex items-center justify-center">
        <div className="flex flex-col items-center gap-6">
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-pink-500 via-purple-500 to-blue-500 flex items-center justify-center animate-pulse shadow-2xl shadow-purple-500/30">
            <LionLogo className="w-12 h-12" />
          </div>
          <div className="flex flex-col items-center gap-2">
            <p className="text-white/60 text-sm">Loading lion.ai...</p>
            <div className="flex gap-1">
              <div className="w-2 h-2 rounded-full bg-pink-400 animate-bounce" style={{ animationDelay: '0ms' }} />
              <div className="w-2 h-2 rounded-full bg-purple-400 animate-bounce" style={{ animationDelay: '150ms' }} />
              <div className="w-2 h-2 rounded-full bg-blue-400 animate-bounce" style={{ animationDelay: '300ms' }} />
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="App">
      {isAuthenticated ? (
        <Dashboard 
          onLogout={handleLogout} 
          userId={userInfo?.userId}
          userEmail={userInfo?.email}
          isAdmin={userInfo?.isAdmin}
          sessionToken={userInfo?.sessionToken}
        />
      ) : (
        <LoginPage onLogin={handleLogin} />
      )}
    </div>
  );
}

export default App;
