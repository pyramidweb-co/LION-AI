import React, { useRef, useEffect, useState } from 'react';
import { Code, Database, Zap, Shield, Sparkles, Eye, EyeOff, Loader2, Brain, Mic, MicOff, Download } from 'lucide-react';
import { ScrollArea } from '../ui/scroll-area';
import { Button } from '../ui/button';
import { ChatMessage, PreviewPanel } from './ChatMessage';
import ChatInput from './ChatInput';
import LionLogo from '../icons/LionLogo';

const WelcomeScreen = ({ sessionSettings, onToggleFeature, ultraMode, onToggleUltra }) => {
  const features = [
    { key: 'lightning_fast', icon: Zap, title: 'Lightning Fast', desc: 'Quick, concise responses', color: 'text-pink-400', bgActive: 'from-pink-500/30 to-pink-500/10' },
    { key: 'full_code', icon: Code, title: 'Full Code', desc: 'Complete projects + ZIP export', color: 'text-purple-400', bgActive: 'from-purple-500/30 to-purple-500/10' },
    { key: 'database', icon: Database, title: 'Database', desc: 'MongoDB schemas included', color: 'text-blue-400', bgActive: 'from-blue-500/30 to-blue-500/10' },
    { key: 'secure', icon: Shield, title: 'Secure', desc: 'Security best practices', color: 'text-emerald-400', bgActive: 'from-emerald-500/30 to-emerald-500/10' }
  ];

  return (
    <div className="flex-1 flex flex-col items-center justify-center p-8">
      <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-pink-500 via-purple-500 to-blue-500 flex items-center justify-center mb-8 shadow-2xl shadow-purple-500/30 animate-pulse-glow">
        <LionLogo className="w-16 h-16" />
      </div>
      
      <h1 className="text-4xl font-bold text-white mb-3">
        Welcome to <span className="gradient-text">lion.ai</span>
      </h1>
      
      <p className="text-white/50 text-center max-w-lg mb-6 text-lg">
        Build full-stack web applications in minutes with the power of AI. 
        Describe what you want, and watch it come to life.
      </p>

      {/* Ultra Mode Toggle */}
      <button
        onClick={onToggleUltra}
        className={`mb-6 px-6 py-3 rounded-xl border transition-all duration-300 flex items-center gap-3 ${
          ultraMode 
            ? 'bg-gradient-to-r from-purple-600/30 to-pink-600/30 border-purple-500 text-white shadow-lg shadow-purple-500/20' 
            : 'bg-white/5 border-white/10 text-white/60 hover:border-purple-500/50 hover:text-white'
        }`}
      >
        <Brain className={`w-5 h-5 ${ultraMode ? 'text-purple-400' : ''}`} />
        <div className="text-left">
          <div className="font-semibold text-sm">Ultra Mode {ultraMode ? 'ON' : 'OFF'}</div>
          <div className="text-xs opacity-70">Deep reasoning for complex tasks</div>
        </div>
      </button>

      {/* Feature Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl w-full">
        {features.map((feature) => {
          const isActive = sessionSettings[feature.key];
          return (
            <button 
              key={feature.key}
              onClick={() => onToggleFeature(feature.key)}
              className={`p-5 rounded-2xl border transition-all duration-300 group text-left ${
                isActive 
                  ? `bg-gradient-to-br ${feature.bgActive} border-${feature.color.replace('text-', '')}/50 shadow-lg` 
                  : 'bg-white/[0.03] border-white/5 hover:border-purple-500/30 hover:bg-white/[0.05]'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <feature.icon className={`w-7 h-7 ${feature.color} group-hover:scale-110 transition-transform`} />
                {isActive && (
                  <div className={`w-2 h-2 rounded-full ${feature.color.replace('text-', 'bg-')} animate-pulse`} />
                )}
              </div>
              <h3 className="text-sm font-semibold text-white mb-1">{feature.title}</h3>
              <p className="text-xs text-white/40">{feature.desc}</p>
            </button>
          );
        })}
      </div>

      {/* Active Features Summary */}
      {Object.values(sessionSettings).some(v => v) && (
        <div className="mt-6 px-4 py-2 rounded-full bg-white/5 border border-white/10">
          <span className="text-xs text-white/60">
            Active: {Object.entries(sessionSettings).filter(([,v]) => v).map(([k]) => 
              features.find(f => f.key === k)?.title
            ).join(', ')}
          </span>
        </div>
      )}

      <div className="mt-8 flex items-center gap-2 text-white/40 text-sm">
        <Sparkles className="w-4 h-4 text-purple-400" />
        <span>Unlimited usage • No credit limits • AI-powered</span>
      </div>
    </div>
  );
};

const TypingIndicator = () => (
  <div className="flex gap-4 py-6 px-4 md:px-6 bg-white/[0.02]">
    <div className="w-9 h-9 rounded-xl flex-shrink-0 flex items-center justify-center bg-gradient-to-br from-pink-500 via-purple-500 to-blue-500">
      <LionLogo className="w-6 h-6" />
    </div>
    <div className="flex flex-col gap-2">
      <span className="text-sm font-semibold gradient-text">Lion AI</span>
      <div className="flex items-center gap-1.5">
        <div className="w-2 h-2 rounded-full bg-purple-400 typing-dot" />
        <div className="w-2 h-2 rounded-full bg-pink-400 typing-dot" />
        <div className="w-2 h-2 rounded-full bg-blue-400 typing-dot" />
        <span className="ml-2 text-sm text-white/40">Generating code...</span>
      </div>
    </div>
  </div>
);

const ChatArea = ({ chat, onSendMessage, isLoading, userId }) => {
  const scrollRef = useRef(null);
  const [showPreview, setShowPreview] = useState(false);
  const [previewCode, setPreviewCode] = useState('');
  const [previewLanguage, setPreviewLanguage] = useState('jsx');
  
  // Session-persistent settings
  const [sessionSettings, setSessionSettings] = useState({
    lightning_fast: false,
    full_code: false,
    database: false,
    secure: false
  });
  const [ultraMode, setUltraMode] = useState(false);

  useEffect(() => {
    if (scrollRef.current) {
      const scrollElement = scrollRef.current.querySelector('[data-radix-scroll-area-viewport]');
      if (scrollElement) {
        scrollElement.scrollTop = scrollElement.scrollHeight;
      }
    }
  }, [chat?.messages, isLoading]);

  // Reset settings on new chat
  useEffect(() => {
    if (!chat || chat.messages?.length === 0) {
      // Keep settings for the session, only reset when explicitly starting fresh
    }
  }, [chat?.id]);

  const handleShowPreview = (code, language) => {
    setPreviewCode(code);
    setPreviewLanguage(language || 'jsx');
    setShowPreview(true);
  };

  const toggleFeature = (key) => {
    setSessionSettings(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  const handleSendWithSettings = (content) => {
    // Pass settings along with message
    onSendMessage(content, { sessionSettings, ultraMode });
  };

  const hasMessages = chat?.messages && chat.messages.length > 0;

  return (
    <div className="flex-1 flex bg-[hsl(240,20%,4%)] h-screen overflow-hidden">
      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <div className="border-b border-white/5 px-6 py-4 bg-[hsl(240,20%,4%)]/80 backdrop-blur-sm flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold text-white">
              {chat?.title || 'New Chat'}
            </h2>
            {chat && (
              <p className="text-sm text-white/40">
                {chat.messages?.length || 0} messages
              </p>
            )}
          </div>
          
          <div className="flex items-center gap-2">
            {/* Ultra Mode indicator */}
            {ultraMode && (
              <div className="flex items-center gap-1 px-3 py-1 rounded-full bg-purple-500/20 border border-purple-500/30">
                <Brain className="w-3 h-3 text-purple-400" />
                <span className="text-xs text-purple-300">Ultra</span>
              </div>
            )}
            
            {/* Active features indicator */}
            {Object.values(sessionSettings).some(v => v) && (
              <div className="flex items-center gap-1 px-3 py-1 rounded-full bg-white/10 border border-white/20">
                <Sparkles className="w-3 h-3 text-white/60" />
                <span className="text-xs text-white/60">
                  {Object.values(sessionSettings).filter(v => v).length} active
                </span>
              </div>
            )}
            
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowPreview(!showPreview)}
              className={`text-white/50 hover:text-white hover:bg-white/10 ${
                showPreview ? 'bg-purple-500/20 text-purple-400' : ''
              }`}
            >
              {showPreview ? <EyeOff className="w-4 h-4 mr-2" /> : <Eye className="w-4 h-4 mr-2" />}
              {showPreview ? 'Hide Preview' : 'Show Preview'}
            </Button>
          </div>
        </div>

        {/* Messages Area */}
        <div className="flex-1 overflow-hidden">
          <ScrollArea className="h-full" ref={scrollRef}>
            {hasMessages ? (
              <div className="pb-4">
                {chat.messages.map((message) => (
                  <ChatMessage 
                    key={message.id} 
                    message={message} 
                    onShowPreview={handleShowPreview}
                  />
                ))}
                {isLoading && <TypingIndicator />}
              </div>
            ) : (
              <WelcomeScreen 
                sessionSettings={sessionSettings}
                onToggleFeature={toggleFeature}
                ultraMode={ultraMode}
                onToggleUltra={() => setUltraMode(!ultraMode)}
              />
            )}
          </ScrollArea>
        </div>

        {/* Input */}
        <ChatInput 
          onSend={handleSendWithSettings} 
          isLoading={isLoading}
          sessionSettings={sessionSettings}
          ultraMode={ultraMode}
          chatId={chat?.id}
        />
      </div>

      {/* Preview Panel */}
      <PreviewPanel 
        code={previewCode}
        language={previewLanguage}
        isOpen={showPreview} 
        onToggle={() => setShowPreview(false)}
      />
    </div>
  );
};

export default ChatArea;
