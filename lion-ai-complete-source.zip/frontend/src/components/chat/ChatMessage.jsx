import React, { useState, useEffect } from 'react';
import LionLogo from '../icons/LionLogo';
import { Copy, Check, User, Code, Eye, ChevronDown, ChevronUp, Download, FileCode, ExternalLink, Play, X, RefreshCw } from 'lucide-react';
import { Button } from '../ui/button';
import { ScrollArea } from '../ui/scroll-area';

// Simple syntax highlighter
const highlightCode = (code, language) => {
  if (!code) return '';
  
  const jsKeywords = ['import', 'export', 'from', 'const', 'let', 'var', 'function', 'return', 'if', 'else', 'for', 'while', 'class', 'extends', 'async', 'await', 'default', 'try', 'catch', 'throw', 'new', 'this', 'true', 'false', 'null', 'undefined'];
  const pyKeywords = ['import', 'from', 'def', 'class', 'return', 'if', 'else', 'elif', 'for', 'while', 'try', 'except', 'with', 'as', 'async', 'await', 'raise', 'True', 'False', 'None', 'and', 'or', 'not', 'in'];
  
  const keywords = language === 'python' || language === 'py' ? pyKeywords : jsKeywords;
  
  let highlighted = code
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/("[^"]*"|'[^']*'|`[^`]*`)/g, '<span class="text-emerald-400">$1</span>')
    .replace(/(#.*$|\/\/.*$|\/\*[\s\S]*?\*\/)/gm, '<span class="text-white/30 italic">$1</span>')
    .replace(/\b(\d+)\b/g, '<span class="text-amber-400">$1</span>');
  
  keywords.forEach(keyword => {
    const regex = new RegExp(`\\b(${keyword})\\b`, 'g');
    highlighted = highlighted.replace(regex, '<span class="text-pink-400">$1</span>');
  });
  
  return highlighted;
};

// Extract filename from code or generate one
const extractFilename = (code, language) => {
  // Try to find filename in comment at start
  const patterns = [
    /^\/\/\s*([\w.-]+\.[\w]+)/m,  // // filename.ext
    /^#\s*([\w.-]+\.[\w]+)/m,     // # filename.ext
    /^{\/\*\s*([\w.-]+\.[\w]+)\s*\*\/}/m,  // {/* filename.ext */}
    /^<!--\s*([\w.-]+\.[\w]+)\s*-->/m,  // <!-- filename.ext -->
  ];
  
  for (const pattern of patterns) {
    const match = code.match(pattern);
    if (match) return match[1];
  }
  
  // Default filenames based on language
  const defaults = {
    'jsx': 'Component.jsx',
    'javascript': 'script.js',
    'js': 'script.js',
    'typescript': 'script.ts',
    'ts': 'script.ts',
    'tsx': 'Component.tsx',
    'python': 'main.py',
    'py': 'main.py',
    'css': 'styles.css',
    'html': 'index.html',
    'json': 'data.json',
    'bash': 'script.sh',
    'sh': 'script.sh',
    'sql': 'query.sql',
  };
  
  return defaults[language] || `code.${language}`;
};

const CodeBlock = ({ code, language = 'javascript', filename: providedFilename, onPreview }) => {
  const [copied, setCopied] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  
  const filename = providedFilename || extractFilename(code, language);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([code], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleOpenInNewTab = () => {
    // Create a full HTML page for preview
    const isReact = language === 'jsx' || language === 'tsx';
    const isHTML = language === 'html';
    const isCSS = language === 'css';
    
    let htmlContent;
    
    if (isHTML) {
      htmlContent = code;
    } else if (isCSS) {
      htmlContent = `<!DOCTYPE html>
<html>
<head>
  <style>${code}</style>
</head>
<body>
  <div class="demo">CSS Preview</div>
</body>
</html>`;
    } else if (isReact) {
      htmlContent = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/react@18/umd/react.development.js"></script>
  <script src="https://unpkg.com/react-dom@18/umd/react-dom.development.js"></script>
  <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: system-ui, -apple-system, sans-serif; }
  </style>
</head>
<body>
  <div id="root"></div>
  <script type="text/babel">
    ${code}
    
    // Try to render the component
    const componentName = Object.keys(window).find(key => 
      typeof window[key] === 'function' && 
      /^[A-Z]/.test(key) &&
      key !== 'React' && key !== 'ReactDOM'
    );
    
    if (typeof App !== 'undefined') {
      ReactDOM.createRoot(document.getElementById('root')).render(<App />);
    } else if (componentName && typeof window[componentName] !== 'undefined') {
      const Component = window[componentName];
      ReactDOM.createRoot(document.getElementById('root')).render(<Component />);
    }
  </script>
</body>
</html>`;
    } else {
      // For other code, just show in a pre tag
      htmlContent = `<!DOCTYPE html>
<html>
<head>
  <style>
    body { background: #1a1a2e; color: #eee; font-family: monospace; padding: 20px; }
    pre { white-space: pre-wrap; word-wrap: break-word; }
  </style>
</head>
<body>
  <pre>${code.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</pre>
</body>
</html>`;
    }
    
    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank');
  };

  const lines = code.split('\n');
  const isPreviewable = ['jsx', 'tsx', 'html', 'css'].includes(language);

  return (
    <div className="my-4 rounded-xl overflow-hidden bg-[hsl(240,20%,6%)] border border-white/10">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2.5 bg-white/5 border-b border-white/10">
        <div className="flex items-center gap-2">
          <FileCode className="w-4 h-4 text-purple-400" />
          <span className="text-sm font-medium text-white/80">{filename}</span>
          <span className="text-xs px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 font-mono">{language}</span>
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setCollapsed(!collapsed)}
            className="h-7 px-2 text-white/50 hover:text-white hover:bg-white/10"
            title={collapsed ? "Expand" : "Collapse"}
          >
            {collapsed ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
          </Button>
          {isPreviewable && (
            <>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onPreview && onPreview(code, language)}
                className="h-7 px-2 text-white/50 hover:text-white hover:bg-white/10"
                title="Preview in panel"
              >
                <Eye className="w-4 h-4" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleOpenInNewTab}
                className="h-7 px-2 text-white/50 hover:text-white hover:bg-white/10"
                title="Open in new tab"
              >
                <ExternalLink className="w-4 h-4" />
              </Button>
            </>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={handleDownload}
            className="h-7 px-2 text-white/50 hover:text-white hover:bg-white/10"
            title="Download"
          >
            <Download className="w-4 h-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleCopy}
            className="h-7 px-2 text-white/50 hover:text-white hover:bg-white/10"
            title="Copy"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
          </Button>
        </div>
      </div>
      
      {/* Code */}
      {!collapsed && (
        <ScrollArea className="max-h-[400px]">
          <pre className="p-4 text-sm font-mono overflow-x-auto">
            <code>
              {lines.map((line, i) => (
                <div key={i} className="flex hover:bg-white/5">
                  <span className="w-10 text-white/20 select-none text-right pr-4 flex-shrink-0">{i + 1}</span>
                  <span className="flex-1" dangerouslySetInnerHTML={{ __html: highlightCode(line, language) || '&nbsp;' }} />
                </div>
              ))}
            </code>
          </pre>
        </ScrollArea>
      )}
    </div>
  );
};

const PreviewPanel = ({ code, language, isOpen, onToggle }) => {
  const [key, setKey] = useState(0);

  const refreshPreview = () => {
    setKey(prev => prev + 1);
  };

  const createPreviewHTML = (code, lang) => {
    const isReact = lang === 'jsx' || lang === 'tsx';
    
    if (isReact) {
      return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/react@18/umd/react.development.js"></script>
  <script src="https://unpkg.com/react-dom@18/umd/react-dom.development.js"></script>
  <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: system-ui, -apple-system, sans-serif; min-height: 100vh; }
  </style>
</head>
<body>
  <div id="root"></div>
  <script type="text/babel">
    ${code}
    
    // Auto-detect and render component
    try {
      if (typeof App !== 'undefined') {
        ReactDOM.createRoot(document.getElementById('root')).render(<App />);
      } else if (typeof HelloWorld !== 'undefined') {
        ReactDOM.createRoot(document.getElementById('root')).render(<HelloWorld />);
      } else if (typeof Counter !== 'undefined') {
        ReactDOM.createRoot(document.getElementById('root')).render(<Counter />);
      } else if (typeof Component !== 'undefined') {
        ReactDOM.createRoot(document.getElementById('root')).render(<Component />);
      }
    } catch(e) {
      document.getElementById('root').innerHTML = '<div style="color:red;padding:20px">Error: ' + e.message + '</div>';
    }
  </script>
</body>
</html>`;
    }
    
    return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: system-ui, -apple-system, sans-serif; }
  </style>
</head>
<body>
  ${code || '<div class="flex items-center justify-center h-screen text-gray-400">Select code to preview</div>'}
</body>
</html>`;
  };

  const handleOpenInNewTab = () => {
    const html = createPreviewHTML(code, language);
    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank');
  };

  if (!isOpen) return null;

  return (
    <div className="border-l border-white/10 bg-[hsl(240,20%,6%)] flex flex-col w-1/2 relative">
      {/* Close Button - Always visible */}
      <button
        onClick={onToggle}
        className="absolute top-3 right-3 z-10 w-8 h-8 rounded-lg bg-white/10 hover:bg-red-500/20 flex items-center justify-center text-white/60 hover:text-red-400 transition-all"
        title="Close Preview"
      >
        <X className="w-5 h-5" />
      </button>

      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-white/10 bg-white/5 pr-14">
        <div className="flex items-center gap-2">
          <Play className="w-4 h-4 text-emerald-400" />
          <span className="text-sm font-medium text-white">Live Preview</span>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={refreshPreview}
            className="text-white/50 hover:text-white hover:bg-white/10 h-8"
          >
            <RefreshCw className="w-4 h-4 mr-1" />
            Refresh
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleOpenInNewTab}
            className="text-white/50 hover:text-white hover:bg-white/10 h-8"
          >
            <ExternalLink className="w-4 h-4 mr-1" />
            Open in Tab
          </Button>
        </div>
      </div>
      
      {/* Preview Frame */}
      <div className="flex-1 p-4 overflow-hidden">
        <div className="h-full rounded-xl overflow-hidden bg-white shadow-2xl">
          {code ? (
            <iframe
              key={key}
              srcDoc={createPreviewHTML(code, language)}
              className="w-full h-full border-0"
              title="Preview"
              sandbox="allow-scripts allow-same-origin"
            />
          ) : (
            <div className="flex items-center justify-center h-full text-gray-400">
              Click "Preview" on a code block to see it here
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const ChatMessage = ({ message, onShowPreview }) => {
  const [copied, setCopied] = useState(false);
  const isAssistant = message.role === 'assistant';

  const handleCopy = async () => {
    await navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const formatTime = (timestamp) => {
    return new Date(timestamp).toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  // Parse message for code blocks
  const parseContent = (content) => {
    const parts = [];
    const codeBlockRegex = /```(\w+)?\n([\s\S]*?)```/g;
    let lastIndex = 0;
    let match;

    while ((match = codeBlockRegex.exec(content)) !== null) {
      if (match.index > lastIndex) {
        parts.push({ type: 'text', content: content.slice(lastIndex, match.index) });
      }
      parts.push({ 
        type: 'code', 
        language: match[1] || 'javascript', 
        content: match[2].trim() 
      });
      lastIndex = match.index + match[0].length;
    }

    if (lastIndex < content.length) {
      parts.push({ type: 'text', content: content.slice(lastIndex) });
    }

    return parts.length > 0 ? parts : [{ type: 'text', content }];
  };

  const contentParts = parseContent(message.content);

  return (
    <div className={`flex gap-4 py-6 px-4 md:px-6 ${
      isAssistant ? 'bg-white/[0.02]' : ''
    }`}>
      {/* Avatar */}
      <div className={`w-9 h-9 rounded-xl flex-shrink-0 flex items-center justify-center ${
        isAssistant 
          ? 'bg-gradient-to-br from-pink-500 via-purple-500 to-blue-500' 
          : 'bg-white/10'
      }`}>
        {isAssistant ? (
          <LionLogo className="w-6 h-6" />
        ) : (
          <User className="w-4 h-4 text-white/70" />
        )}
      </div>

      {/* Content */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-2">
          <span className={`text-sm font-semibold ${
            isAssistant ? 'gradient-text' : 'text-white/70'
          }`}>
            {isAssistant ? 'Lion AI' : 'You'}
          </span>
          <span className="text-xs text-white/30">
            {formatTime(message.timestamp)}
          </span>
        </div>
        
        <div className="text-white/90 leading-relaxed">
          {contentParts.map((part, index) => (
            part.type === 'code' ? (
              <CodeBlock 
                key={index} 
                code={part.content} 
                language={part.language}
                onPreview={(code, lang) => onShowPreview(code, lang)}
              />
            ) : (
              <div key={index} className="whitespace-pre-wrap">{part.content}</div>
            )
          ))}
        </div>

        {/* Actions */}
        {isAssistant && (
          <div className="flex items-center gap-2 mt-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleCopy}
              className="h-8 px-3 text-white/40 hover:text-white hover:bg-white/10 text-xs"
            >
              {copied ? (
                <><Check className="w-3 h-3 mr-1.5" /> Copied!</>
              ) : (
                <><Copy className="w-3 h-3 mr-1.5" /> Copy all</>
              )}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export { ChatMessage, CodeBlock, PreviewPanel };
