import React, { useState, useRef, useEffect } from 'react';
import { Send, Paperclip, Sparkles, Loader2, X, FileText, ImageIcon, Mic, MicOff, Download } from 'lucide-react';
import { Button } from '../ui/button';
import { Textarea } from '../ui/textarea';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const ChatInput = ({ onSend, isLoading, disabled, sessionSettings, ultraMode, chatId }) => {
  const [message, setMessage] = useState('');
  const [attachments, setAttachments] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const textareaRef = useRef(null);
  const fileInputRef = useRef(null);
  const recognitionRef = useRef(null);
  const isListeningRef = useRef(false);

  // Sync ref with state for use in callbacks
  useEffect(() => {
    isListeningRef.current = isListening;
  }, [isListening]);

  // Check for Web Speech API support on mount
  const speechSupported = typeof window !== 'undefined' && 
    (window.SpeechRecognition || window.webkitSpeechRecognition);

  // Initialize speech recognition
  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition && !recognitionRef.current) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = true;
      recognitionRef.current.lang = 'en-US';

      recognitionRef.current.onresult = (event) => {
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            finalTranscript += transcript;
          }
        }

        if (finalTranscript) {
          setMessage(prev => prev + finalTranscript);
        }
      };

      recognitionRef.current.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
      };

      recognitionRef.current.onend = () => {
        if (isListeningRef.current) {
          // Restart if still supposed to be listening
          try {
            recognitionRef.current.start();
          } catch (e) {
            setIsListening(false);
          }
        }
      };
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, []);

  // Handle listening state changes
  useEffect(() => {
    if (!recognitionRef.current) return;

    if (isListening) {
      try {
        recognitionRef.current.start();
      } catch (e) {
        // Already started
      }
    } else {
      recognitionRef.current.stop();
    }
  }, [isListening]);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
    }
  }, [message]);

  const toggleVoiceInput = () => {
    setIsListening(!isListening);
  };

  const handleFileUpload = async (files) => {
    if (!files || files.length === 0) return;
    
    setUploading(true);
    const newAttachments = [];
    
    for (const file of files) {
      try {
        const formData = new FormData();
        formData.append('file', file);
        
        const response = await axios.post(`${API}/upload`, formData, {
          headers: { 'Content-Type': 'multipart/form-data' }
        });
        
        if (response.data.success) {
          newAttachments.push({
            id: response.data.saved_as,
            name: response.data.filename,
            url: `${BACKEND_URL}${response.data.url}`,
            isImage: response.data.is_image,
            size: response.data.size
          });
        }
      } catch (error) {
        console.error('Upload failed:', error);
      }
    }
    
    setAttachments(prev => [...prev, ...newAttachments]);
    setUploading(false);
  };

  const handleAttachClick = () => {
    fileInputRef.current?.click();
  };

  const removeAttachment = (id) => {
    setAttachments(prev => prev.filter(a => a.id !== id));
  };

  const handleExportCode = async () => {
    if (!chatId) return;
    try {
      window.open(`${API}/chats/${chatId}/export`, '_blank');
    } catch (error) {
      console.error('Export failed:', error);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if ((message.trim() || attachments.length > 0) && !isLoading && !disabled) {
      // Stop listening when sending
      if (isListening) {
        setIsListening(false);
      }

      // Build message with attachments
      let fullMessage = message.trim();
      
      if (attachments.length > 0) {
        const attachmentText = attachments.map(a => {
          if (a.isImage) {
            return `\n[Image: ${a.name}](${a.url})`;
          }
          return `\n[File: ${a.name}](${a.url})`;
        }).join('');
        fullMessage = fullMessage + attachmentText;
      }
      
      onSend(fullMessage);
      setMessage('');
      setAttachments([]);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const suggestions = [
    "Build me an e-commerce website",
    "Create a dashboard with charts",
    "Design a blog with authentication",
    "Make a social media app"
  ];

  const formatFileSize = (bytes) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  return (
    <div className="border-t border-white/5 bg-[hsl(240,20%,4%)]/80 backdrop-blur-sm p-4">
      {/* Hidden file input - accepts all files */}
      <input
        type="file"
        ref={fileInputRef}
        className="hidden"
        multiple
        accept="image/*,.pdf,.doc,.docx,.txt,.json,.js,.jsx,.ts,.tsx,.py,.html,.css,.md"
        onChange={(e) => handleFileUpload(e.target.files)}
      />

      {/* Suggestions */}
      {!message && !isLoading && attachments.length === 0 && (
        <div className="flex flex-wrap gap-2 mb-4 justify-center">
          {suggestions.map((suggestion, index) => (
            <button
              key={index}
              onClick={() => setMessage(suggestion)}
              className="px-4 py-2 text-sm bg-white/5 text-white/60 rounded-full border border-white/10 hover:border-purple-500/50 hover:text-white hover:bg-white/10 transition-all duration-200"
            >
              <Sparkles className="w-3 h-3 inline mr-2 text-purple-400" />
              {suggestion}
            </button>
          ))}
        </div>
      )}

      {/* Attachments Preview */}
      {attachments.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-3 max-w-4xl mx-auto">
          {attachments.map((attachment) => (
            <div
              key={attachment.id}
              className="relative group flex items-center gap-2 px-3 py-2 bg-white/10 rounded-lg border border-white/20"
            >
              {attachment.isImage ? (
                <div className="flex items-center gap-2">
                  <img 
                    src={attachment.url} 
                    alt={attachment.name}
                    className="w-10 h-10 object-cover rounded"
                  />
                  <div className="flex flex-col">
                    <span className="text-xs text-white/80 truncate max-w-[120px]">{attachment.name}</span>
                    <span className="text-xs text-white/40">{formatFileSize(attachment.size)}</span>
                  </div>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <FileText className="w-6 h-6 text-purple-400" />
                  <div className="flex flex-col">
                    <span className="text-xs text-white/80 truncate max-w-[120px]">{attachment.name}</span>
                    <span className="text-xs text-white/40">{formatFileSize(attachment.size)}</span>
                  </div>
                </div>
              )}
              <button
                onClick={() => removeAttachment(attachment.id)}
                className="absolute -top-2 -right-2 w-5 h-5 bg-red-500 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <X className="w-3 h-3 text-white" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Input Form */}
      <form onSubmit={handleSubmit} className="max-w-4xl mx-auto">
        <div className="relative flex items-end gap-2 bg-white/5 rounded-2xl border border-white/10 focus-within:border-purple-500/50 focus-within:ring-1 focus-within:ring-purple-500/20 transition-all duration-200">
          <Textarea
            ref={textareaRef}
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={isListening ? "Listening... speak now" : "Describe the app you want to build..."}
            disabled={isLoading || disabled || uploading}
            className={`flex-1 bg-transparent border-0 resize-none text-white placeholder:text-white/30 focus:ring-0 focus-visible:ring-0 min-h-[56px] max-h-[200px] py-4 px-5 disabled:opacity-50 ${
              isListening ? 'placeholder:text-pink-400' : ''
            }`}
            rows={1}
          />

          <div className="flex items-center gap-1 p-3">
            {/* Unified Attachment Button */}
            <Button
              type="button"
              variant="ghost"
              size="icon"
              disabled={isLoading || uploading}
              onClick={handleAttachClick}
              className="text-white/40 hover:text-white hover:bg-white/10 disabled:opacity-30"
              title="Attach files or images"
            >
              {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Paperclip className="w-4 h-4" />}
            </Button>

            {/* Voice Input Button */}
            {speechSupported && (
              <Button
                type="button"
                variant="ghost"
                size="icon"
                disabled={isLoading || uploading}
                onClick={toggleVoiceInput}
                className={`transition-all duration-200 ${
                  isListening 
                    ? 'text-pink-400 bg-pink-500/20 hover:bg-pink-500/30 animate-pulse' 
                    : 'text-white/40 hover:text-white hover:bg-white/10'
                } disabled:opacity-30`}
                title={isListening ? "Stop listening" : "Start voice input"}
              >
                {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              </Button>
            )}

            {/* Export Button - only show if there's a chat */}
            {chatId && (
              <Button
                type="button"
                variant="ghost"
                size="icon"
                disabled={isLoading}
                onClick={handleExportCode}
                className="text-white/40 hover:text-white hover:bg-white/10 disabled:opacity-30"
                title="Export code as ZIP"
              >
                <Download className="w-4 h-4" />
              </Button>
            )}

            {/* Send Button */}
            <Button
              type="submit"
              disabled={(!message.trim() && attachments.length === 0) || isLoading || disabled || uploading}
              className="bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 hover:opacity-90 text-white disabled:opacity-30 disabled:cursor-not-allowed h-10 w-10"
            >
              {isLoading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Send className="w-4 h-4" />
              )}
            </Button>
          </div>
        </div>

        {/* Voice indicator */}
        {isListening && (
          <div className="flex items-center justify-center mt-2 gap-2">
            <div className="flex gap-1">
              <div className="w-1 h-3 bg-pink-400 rounded-full animate-pulse" style={{ animationDelay: '0ms' }} />
              <div className="w-1 h-4 bg-purple-400 rounded-full animate-pulse" style={{ animationDelay: '150ms' }} />
              <div className="w-1 h-3 bg-blue-400 rounded-full animate-pulse" style={{ animationDelay: '300ms' }} />
              <div className="w-1 h-5 bg-pink-400 rounded-full animate-pulse" style={{ animationDelay: '450ms' }} />
              <div className="w-1 h-3 bg-purple-400 rounded-full animate-pulse" style={{ animationDelay: '600ms' }} />
            </div>
            <span className="text-xs text-white/50">Listening...</span>
          </div>
        )}
      </form>

      {/* Footer Note */}
      <div className="text-center mt-3">
        <p className="text-xs text-white/30">
          Lion AI can make mistakes. Consider checking important information.
        </p>
      </div>
    </div>
  );
};

export default ChatInput;
