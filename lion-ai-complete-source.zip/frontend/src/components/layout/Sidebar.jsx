import React, { useState } from 'react';
import { 
  Plus, 
  MessageSquare, 
  LogOut, 
  ChevronLeft,
  ChevronRight,
  Search,
  Infinity,
  Trash2,
  MoreHorizontal,
  Shield,
  Edit2,
  Check,
  X
} from 'lucide-react';
import LionLogo from '../icons/LionLogo';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { ScrollArea } from '../ui/scroll-area';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '../ui/tooltip';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "../ui/dropdown-menu";

const Sidebar = ({ 
  chats, 
  activeChat, 
  onSelectChat, 
  onNewChat, 
  onDeleteChat,
  onRenameChat,
  collapsed, 
  onToggleCollapse,
  userEmail,
  onLogout,
  isAdmin,
  onOpenAdminPanel
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [editingChatId, setEditingChatId] = useState(null);
  const [editTitle, setEditTitle] = useState('');

  const filteredChats = chats.filter(chat => 
    chat.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    return date.toLocaleDateString();
  };

  const startEditing = (chat) => {
    setEditingChatId(chat.id);
    setEditTitle(chat.title);
  };

  const cancelEditing = () => {
    setEditingChatId(null);
    setEditTitle('');
  };

  const saveEdit = (chatId) => {
    if (editTitle.trim()) {
      onRenameChat(chatId, editTitle.trim());
    }
    cancelEditing();
  };

  return (
    <div 
      className={`h-screen bg-[hsl(240,20%,5%)] border-r border-white/5 flex flex-col transition-all duration-300 ${
        collapsed ? 'w-16' : 'w-72'
      }`}
    >
      {/* Header */}
      <div className="p-4 border-b border-white/5">
        <div className="flex items-center justify-between">
          {!collapsed && (
            <div className="flex items-center gap-2">
              <LionLogo className="w-8 h-8" />
              <span className="font-bold text-xl">
                <span className="text-white">lion</span>
                <span className="gradient-text">.ai</span>
              </span>
            </div>
          )}
          {collapsed && <LionLogo className="w-8 h-8 mx-auto" />}
          {!collapsed && (
            <Button
              variant="ghost"
              size="icon"
              onClick={onToggleCollapse}
              className="text-white/40 hover:text-white hover:bg-white/5"
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
          )}
        </div>
        {collapsed && (
          <Button
            variant="ghost"
            size="icon"
            onClick={onToggleCollapse}
            className="w-full mt-2 text-white/40 hover:text-white hover:bg-white/5"
          >
            <ChevronRight className="w-4 h-4" />
          </Button>
        )}
      </div>

      {/* New Chat Button */}
      <div className="p-3">
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button 
                onClick={onNewChat}
                className={`w-full bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 hover:opacity-90 text-white font-medium shadow-lg shadow-purple-500/20 transition-all duration-200 ${
                  collapsed ? 'px-0' : ''
                }`}
                data-testid="new-chat-btn"
              >
                <Plus className="w-4 h-4" />
                {!collapsed && <span className="ml-2">New Chat</span>}
              </Button>
            </TooltipTrigger>
            {collapsed && <TooltipContent side="right">New Chat</TooltipContent>}
          </Tooltip>
        </TooltipProvider>
      </div>

      {/* Search */}
      {!collapsed && (
        <div className="px-3 pb-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
            <Input 
              placeholder="Search chats..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 bg-white/5 border-white/10 text-white placeholder:text-white/30 focus:border-purple-500/50 focus:ring-purple-500/20"
              data-testid="search-chats"
            />
          </div>
        </div>
      )}

      {/* Chat List */}
      <ScrollArea className="flex-1 px-2">
        <div className="space-y-1 py-2">
          {filteredChats.length === 0 && !collapsed && (
            <div className="text-center py-8 text-white/30 text-sm">
              No chats yet. Start a new one!
            </div>
          )}
          {filteredChats.map((chat) => (
            <TooltipProvider key={chat.id}>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div
                    className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl transition-all duration-200 text-left group cursor-pointer ${
                      activeChat === chat.id
                        ? 'bg-gradient-to-r from-pink-500/20 via-purple-500/10 to-blue-500/10 border border-purple-500/30 text-white'
                        : 'text-white/60 hover:bg-white/5 hover:text-white'
                    }`}
                    onClick={() => editingChatId !== chat.id && onSelectChat(chat.id)}
                    data-testid={`chat-item-${chat.id}`}
                  >
                    <MessageSquare className={`w-4 h-4 flex-shrink-0 ${
                      activeChat === chat.id ? 'text-purple-400' : 'text-white/30 group-hover:text-purple-400'
                    }`} />
                    {!collapsed && (
                      <>
                        {editingChatId === chat.id ? (
                          <div className="flex-1 flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                            <Input
                              value={editTitle}
                              onChange={(e) => setEditTitle(e.target.value)}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') saveEdit(chat.id);
                                if (e.key === 'Escape') cancelEditing();
                              }}
                              className="h-7 text-sm bg-white/10 border-white/20"
                              autoFocus
                            />
                            <button 
                              onClick={() => saveEdit(chat.id)}
                              className="p-1 hover:bg-white/10 rounded"
                            >
                              <Check className="w-4 h-4 text-emerald-400" />
                            </button>
                            <button 
                              onClick={cancelEditing}
                              className="p-1 hover:bg-white/10 rounded"
                            >
                              <X className="w-4 h-4 text-red-400" />
                            </button>
                          </div>
                        ) : (
                          <>
                            <div className="flex-1 min-w-0">
                              <div className="text-sm font-medium truncate">{chat.title}</div>
                              <div className="text-xs text-white/30 truncate">{formatDate(chat.createdAt)}</div>
                            </div>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <button 
                                  className="opacity-0 group-hover:opacity-100 p-1 hover:bg-white/10 rounded transition-all"
                                  onClick={(e) => e.stopPropagation()}
                                >
                                  <MoreHorizontal className="w-4 h-4" />
                                </button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end" className="bg-[hsl(240,20%,8%)] border-white/10">
                                <DropdownMenuItem 
                                  className="text-white/70 focus:text-white focus:bg-white/10 cursor-pointer"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    startEditing(chat);
                                  }}
                                >
                                  <Edit2 className="w-4 h-4 mr-2" />
                                  Rename
                                </DropdownMenuItem>
                                <DropdownMenuSeparator className="bg-white/10" />
                                <DropdownMenuItem 
                                  className="text-red-400 focus:text-red-400 focus:bg-red-500/10 cursor-pointer"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    onDeleteChat(chat.id);
                                  }}
                                >
                                  <Trash2 className="w-4 h-4 mr-2" />
                                  Delete
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </>
                        )}
                      </>
                    )}
                  </div>
                </TooltipTrigger>
                {collapsed && <TooltipContent side="right">{chat.title}</TooltipContent>}
              </Tooltip>
            </TooltipProvider>
          ))}
        </div>
      </ScrollArea>

      {/* User Section */}
      <div className="p-3 border-t border-white/5">
        {/* Credits Display */}
        {!collapsed && (
          <div className="mb-3 p-3 rounded-xl bg-gradient-to-r from-pink-500/10 via-purple-500/10 to-blue-500/10 border border-purple-500/20">
            <div className="flex items-center justify-between">
              <span className="text-xs text-white/50">Credits</span>
              <div className="flex items-center gap-1 gradient-text font-bold">
                <Infinity className="w-4 h-4" />
                <span className="text-sm">Unlimited</span>
              </div>
            </div>
          </div>
        )}

        {/* Admin Panel Button */}
        {isAdmin && !collapsed && (
          <Button
            onClick={onOpenAdminPanel}
            className="w-full mb-3 bg-purple-500/20 text-purple-400 hover:bg-purple-500/30 border border-purple-500/30"
            data-testid="admin-panel-btn"
          >
            <Shield className="w-4 h-4 mr-2" />
            Admin Panel
          </Button>
        )}
        {isAdmin && collapsed && (
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  onClick={onOpenAdminPanel}
                  size="icon"
                  className="w-full mb-3 bg-purple-500/20 text-purple-400 hover:bg-purple-500/30"
                >
                  <Shield className="w-4 h-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="right">Admin Panel</TooltipContent>
            </Tooltip>
          </TooltipProvider>
        )}

        {/* User Info & Actions */}
        <div className={`flex items-center gap-2 ${collapsed ? 'flex-col' : ''}`}>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <button className="flex items-center gap-2 flex-1 p-2 rounded-xl hover:bg-white/5 transition-colors">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-pink-500 via-purple-500 to-blue-500 flex items-center justify-center text-white font-medium text-sm">
                    {userEmail?.charAt(0)?.toUpperCase() || 'U'}
                  </div>
                  {!collapsed && (
                    <div className="flex-1 text-left min-w-0">
                      <div className="text-sm font-medium text-white truncate">{userEmail}</div>
                      <div className="text-xs text-white/40">{isAdmin ? 'Admin' : 'User'}</div>
                    </div>
                  )}
                </button>
              </TooltipTrigger>
              {collapsed && <TooltipContent side="right">{userEmail}</TooltipContent>}
            </Tooltip>
          </TooltipProvider>

          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={onLogout}
                  className="text-white/40 hover:text-red-400 hover:bg-red-500/10"
                  data-testid="logout-btn"
                >
                  <LogOut className="w-4 h-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent side={collapsed ? 'right' : 'top'}>Logout</TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
