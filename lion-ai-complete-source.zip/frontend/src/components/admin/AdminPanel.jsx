import React, { useState, useEffect } from 'react';
import { CheckCircle, XCircle, Users, Shield, Trash2, RefreshCw, ArrowLeft, Plus, Mail, UserX, Activity, FileText, BarChart3 } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { ScrollArea } from '../ui/scroll-area';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const AdminPanel = ({ adminEmail, onClose }) => {
  const [activeTab, setActiveTab] = useState('whitelist'); // whitelist, users, stats, logs
  const [whitelist, setWhitelist] = useState([]);
  const [users, setUsers] = useState([]);
  const [stats, setStats] = useState(null);
  const [logs, setLogs] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [newEmail, setNewEmail] = useState('');
  const [actionLoading, setActionLoading] = useState(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    loadData();
  }, [activeTab]);

  const loadData = async () => {
    setIsLoading(true);
    setError('');
    try {
      if (activeTab === 'whitelist') {
        const response = await axios.get(`${API}/admin/whitelist?admin_email=${adminEmail}`);
        setWhitelist(response.data.whitelist || []);
      } else if (activeTab === 'users') {
        const response = await axios.get(`${API}/admin/users?admin_email=${adminEmail}`);
        setUsers(response.data.users || []);
      } else if (activeTab === 'stats') {
        const response = await axios.get(`${API}/admin/stats?admin_email=${adminEmail}`);
        setStats(response.data);
      } else if (activeTab === 'logs') {
        const response = await axios.get(`${API}/admin/logs?admin_email=${adminEmail}&limit=50`);
        setLogs(response.data.logs || []);
      }
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to load data');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddToWhitelist = async (e) => {
    e.preventDefault();
    if (!newEmail.trim()) return;

    setActionLoading('add');
    setError('');
    setSuccess('');

    try {
      const response = await axios.post(`${API}/admin/whitelist/add`, {
        email: newEmail.trim().toLowerCase(),
        admin_email: adminEmail
      });
      
      if (response.data.success) {
        setSuccess(`${newEmail} added to whitelist`);
        setNewEmail('');
        loadData();
      } else {
        setError(response.data.message);
      }
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to add email');
    } finally {
      setActionLoading(null);
    }
  };

  const handleRemoveFromWhitelist = async (email) => {
    setActionLoading(email);
    setError('');

    try {
      await axios.post(`${API}/admin/whitelist/remove`, {
        email,
        admin_email: adminEmail
      });
      setSuccess(`${email} removed from whitelist`);
      loadData();
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to remove email');
    } finally {
      setActionLoading(null);
    }
  };

  const handleDeleteUser = async (userId) => {
    if (!window.confirm('Are you sure you want to delete this user and all their data? This cannot be undone.')) {
      return;
    }

    setActionLoading(userId);
    setError('');

    try {
      await axios.delete(`${API}/admin/users/${userId}?admin_email=${adminEmail}`);
      setSuccess('User deleted successfully');
      loadData();
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to delete user');
    } finally {
      setActionLoading(null);
    }
  };

  const formatDate = (dateStr) => {
    if (!dateStr) return 'N/A';
    const date = new Date(dateStr);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const tabs = [
    { id: 'whitelist', label: 'Whitelist', icon: Mail },
    { id: 'users', label: 'Users', icon: Users },
    { id: 'stats', label: 'Statistics', icon: BarChart3 },
    { id: 'logs', label: 'Logs', icon: FileText },
  ];

  return (
    <div className="fixed inset-0 bg-[hsl(240,20%,4%)] z-50 flex flex-col">
      {/* Header */}
      <div className="border-b border-white/10 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="text-white/60 hover:text-white"
            data-testid="back-btn"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Chat
          </Button>
          <div className="h-6 w-px bg-white/10" />
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-purple-400" />
            <span className="font-semibold text-white">Admin Panel</span>
          </div>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={loadData}
          className="text-white/60 hover:text-white"
        >
          <RefreshCw className={`w-4 h-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </div>

      {/* Tabs */}
      <div className="px-6 py-3 border-b border-white/10">
        <div className="flex gap-2">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2 rounded-lg flex items-center gap-2 transition-all ${
                activeTab === tab.id 
                  ? 'bg-purple-500/20 text-purple-400' 
                  : 'bg-white/5 text-white/60 hover:bg-white/10'
              }`}
              data-testid={`tab-${tab.id}`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Messages */}
      {(error || success) && (
        <div className="px-6 pt-4">
          {error && (
            <div className="p-3 rounded-lg bg-red-500/20 border border-red-500/30 text-red-400 text-sm">
              {error}
            </div>
          )}
          {success && (
            <div className="p-3 rounded-lg bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 text-sm">
              {success}
            </div>
          )}
        </div>
      )}

      {/* Content */}
      <ScrollArea className="flex-1 p-6">
        {isLoading ? (
          <div className="flex items-center justify-center h-64">
            <div className="flex flex-col items-center gap-4">
              <RefreshCw className="w-8 h-8 text-purple-400 animate-spin" />
              <p className="text-white/60">Loading...</p>
            </div>
          </div>
        ) : (
          <div className="max-w-4xl mx-auto">
            {/* Whitelist Tab */}
            {activeTab === 'whitelist' && (
              <div className="space-y-6">
                {/* Add Email Form */}
                <form onSubmit={handleAddToWhitelist} className="flex gap-3">
                  <Input
                    type="email"
                    placeholder="Enter email to whitelist..."
                    value={newEmail}
                    onChange={(e) => setNewEmail(e.target.value)}
                    className="flex-1 bg-white/5 border-white/20 text-white placeholder:text-white/30"
                    data-testid="whitelist-email-input"
                  />
                  <Button
                    type="submit"
                    disabled={actionLoading === 'add' || !newEmail.trim()}
                    className="bg-gradient-to-r from-pink-500 to-purple-500"
                    data-testid="add-whitelist-btn"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add
                  </Button>
                </form>

                {/* Whitelist */}
                <div className="space-y-2">
                  <h3 className="text-sm font-medium text-white/60 mb-3">
                    Whitelisted Emails ({whitelist.length})
                  </h3>
                  {whitelist.length === 0 ? (
                    <div className="text-center py-8 text-white/40">
                      No emails whitelisted yet
                    </div>
                  ) : (
                    whitelist.map((item) => (
                      <div
                        key={item.id || item.email}
                        className="p-4 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-emerald-500/20 flex items-center justify-center">
                            <CheckCircle className="w-5 h-5 text-emerald-400" />
                          </div>
                          <div>
                            <p className="font-medium text-white">{item.email}</p>
                            <p className="text-xs text-white/40">Added: {formatDate(item.added_at)}</p>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleRemoveFromWhitelist(item.email)}
                          disabled={actionLoading === item.email}
                          className="text-red-400 hover:bg-red-500/20"
                        >
                          <XCircle className="w-4 h-4 mr-1" />
                          Remove
                        </Button>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}

            {/* Users Tab */}
            {activeTab === 'users' && (
              <div className="space-y-2">
                <h3 className="text-sm font-medium text-white/60 mb-3">
                  Registered Users ({users.length})
                </h3>
                {users.length === 0 ? (
                  <div className="text-center py-8 text-white/40">
                    No users registered yet
                  </div>
                ) : (
                  users.map((user) => (
                    <div
                      key={user.id}
                      className="p-4 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                          user.is_admin ? 'bg-purple-500/20' : 'bg-blue-500/20'
                        }`}>
                          {user.is_admin ? (
                            <Shield className="w-5 h-5 text-purple-400" />
                          ) : (
                            <Users className="w-5 h-5 text-blue-400" />
                          )}
                        </div>
                        <div>
                          <p className="font-medium text-white flex items-center gap-2">
                            {user.email}
                            {user.is_admin && (
                              <span className="text-xs px-2 py-0.5 rounded bg-purple-500/20 text-purple-400">
                                Admin
                              </span>
                            )}
                          </p>
                          <p className="text-xs text-white/40">Joined: {formatDate(user.createdAt)}</p>
                        </div>
                      </div>
                      {!user.is_admin && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeleteUser(user.id)}
                          disabled={actionLoading === user.id}
                          className="text-red-400 hover:bg-red-500/20"
                        >
                          <UserX className="w-4 h-4 mr-1" />
                          Delete
                        </Button>
                      )}
                    </div>
                  ))
                )}
              </div>
            )}

            {/* Stats Tab */}
            {activeTab === 'stats' && stats && (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="p-6 rounded-xl bg-gradient-to-br from-blue-500/20 to-blue-600/10 border border-blue-500/20">
                  <Users className="w-8 h-8 text-blue-400 mb-3" />
                  <p className="text-3xl font-bold text-white">{stats.total_users}</p>
                  <p className="text-sm text-white/60">Total Users</p>
                </div>
                <div className="p-6 rounded-xl bg-gradient-to-br from-purple-500/20 to-purple-600/10 border border-purple-500/20">
                  <Activity className="w-8 h-8 text-purple-400 mb-3" />
                  <p className="text-3xl font-bold text-white">{stats.total_chats}</p>
                  <p className="text-sm text-white/60">Total Chats</p>
                </div>
                <div className="p-6 rounded-xl bg-gradient-to-br from-pink-500/20 to-pink-600/10 border border-pink-500/20">
                  <FileText className="w-8 h-8 text-pink-400 mb-3" />
                  <p className="text-3xl font-bold text-white">{stats.total_messages}</p>
                  <p className="text-sm text-white/60">Total Messages</p>
                </div>
                <div className="p-6 rounded-xl bg-gradient-to-br from-emerald-500/20 to-emerald-600/10 border border-emerald-500/20">
                  <Mail className="w-8 h-8 text-emerald-400 mb-3" />
                  <p className="text-3xl font-bold text-white">{stats.whitelisted_emails}</p>
                  <p className="text-sm text-white/60">Whitelisted</p>
                </div>
              </div>
            )}

            {/* Logs Tab */}
            {activeTab === 'logs' && (
              <div className="space-y-2">
                <h3 className="text-sm font-medium text-white/60 mb-3">
                  Admin Action Logs
                </h3>
                {logs.length === 0 ? (
                  <div className="text-center py-8 text-white/40">
                    No admin actions logged yet
                  </div>
                ) : (
                  logs.map((log, index) => (
                    <div
                      key={log.id || index}
                      className="p-4 rounded-xl bg-white/5 border border-white/10"
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium text-white">{log.action}</p>
                          <p className="text-sm text-white/40">
                            By: {log.admin_email} • {formatDate(log.timestamp)}
                          </p>
                        </div>
                        <code className="text-xs text-white/30 bg-white/5 px-2 py-1 rounded">
                          {JSON.stringify(log.details)}
                        </code>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}
          </div>
        )}
      </ScrollArea>
    </div>
  );
};

export default AdminPanel;
