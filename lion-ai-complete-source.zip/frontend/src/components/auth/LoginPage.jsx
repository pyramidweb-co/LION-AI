import React, { useState, useRef, useEffect } from 'react';
import { Mail, Lock, Loader2, ShieldAlert, ArrowLeft, CheckCircle2 } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import LionLogo from '../icons/LionLogo';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const LoginPage = ({ onLogin }) => {
  const [step, setStep] = useState('email'); // email, pin, create_pin
  const [email, setEmail] = useState('');
  const [pin, setPin] = useState(['', '', '', '']);
  const [confirmPin, setConfirmPin] = useState(['', '', '', '']);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [isAdmin, setIsAdmin] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  
  const pinRefs = [useRef(), useRef(), useRef(), useRef()];
  const confirmPinRefs = [useRef(), useRef(), useRef(), useRef()];

  const handleEmailSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      const response = await axios.post(`${API}/auth/check-email`, { email });
      const data = response.data;

      if (!data.allowed) {
        setError(data.message || 'Access denied');
        setIsLoading(false);
        return;
      }

      setIsAdmin(data.is_admin);

      if (data.status === 'new_user') {
        setStep('create_pin');
      } else {
        setStep('pin');
      }
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to check email. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handlePinChange = (index, value, isConfirm = false) => {
    if (!/^\d*$/.test(value)) return;
    
    const newPin = isConfirm ? [...confirmPin] : [...pin];
    newPin[index] = value.slice(-1);
    
    if (isConfirm) {
      setConfirmPin(newPin);
    } else {
      setPin(newPin);
    }

    // Auto-focus next input
    if (value && index < 3) {
      const refs = isConfirm ? confirmPinRefs : pinRefs;
      refs[index + 1].current?.focus();
    }
  };

  const handlePinKeyDown = (index, e, isConfirm = false) => {
    if (e.key === 'Backspace' && !e.target.value && index > 0) {
      const refs = isConfirm ? confirmPinRefs : pinRefs;
      refs[index - 1].current?.focus();
    }
  };

  const handlePinPaste = (e, isConfirm = false) => {
    e.preventDefault();
    const pastedData = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 4);
    const newPin = pastedData.split('').concat(['', '', '', '']).slice(0, 4);
    
    if (isConfirm) {
      setConfirmPin(newPin);
    } else {
      setPin(newPin);
    }
  };

  const handleLoginSubmit = async (e) => {
    e.preventDefault();
    const pinValue = pin.join('');
    
    if (pinValue.length !== 4) {
      setError('Please enter a 4-digit PIN');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      const response = await axios.post(`${API}/auth/login`, {
        email,
        pin: pinValue
      });

      const data = response.data;
      
      if (data.success) {
        onLogin({
          userId: data.user_id,
          email: data.email,
          isAdmin: data.is_admin,
          sessionToken: data.session_token
        });
      }
    } catch (err) {
      setError(err.response?.data?.detail || 'Invalid PIN. Please try again.');
      setPin(['', '', '', '']);
      pinRefs[0].current?.focus();
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreatePinSubmit = async (e) => {
    e.preventDefault();
    const pinValue = pin.join('');
    const confirmPinValue = confirmPin.join('');

    if (pinValue.length !== 4) {
      setError('Please enter a 4-digit PIN');
      return;
    }

    if (pinValue !== confirmPinValue) {
      setError('PINs do not match. Please try again.');
      setConfirmPin(['', '', '', '']);
      confirmPinRefs[0].current?.focus();
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      const response = await axios.post(`${API}/auth/register`, {
        email,
        pin: pinValue
      });

      const data = response.data;
      
      if (data.success) {
        setSuccessMessage('Account created successfully!');
        setTimeout(() => {
          onLogin({
            userId: data.user_id,
            email: data.email,
            isAdmin: data.is_admin,
            sessionToken: data.session_token
          });
        }, 1000);
      }
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to create account. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const goBack = () => {
    setStep('email');
    setPin(['', '', '', '']);
    setConfirmPin(['', '', '', '']);
    setError('');
  };

  // Auto-focus first PIN input when step changes
  useEffect(() => {
    if (step === 'pin') {
      pinRefs[0].current?.focus();
    } else if (step === 'create_pin') {
      pinRefs[0].current?.focus();
    }
  }, [step]);

  const PinInputGroup = ({ values, onChange, onKeyDown, onPaste, refs, disabled }) => (
    <div className="flex gap-3 justify-center">
      {values.map((digit, index) => (
        <input
          key={index}
          ref={refs[index]}
          type="password"
          inputMode="numeric"
          maxLength={1}
          value={digit}
          onChange={(e) => onChange(index, e.target.value)}
          onKeyDown={(e) => onKeyDown(index, e)}
          onPaste={onPaste}
          disabled={disabled}
          className="w-14 h-14 text-center text-2xl font-bold bg-white/5 border border-white/20 rounded-xl text-white focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 outline-none transition-all disabled:opacity-50"
          data-testid={`pin-input-${index}`}
        />
      ))}
    </div>
  );

  return (
    <div className="min-h-screen matrix-bg flex">
      {/* Left Panel - Login Form */}
      <div className="flex-1 flex items-center justify-center p-8">
        <div className="w-full max-w-md">
          {/* Logo */}
          <div className="flex items-center gap-3 mb-8">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-pink-500 via-purple-500 to-blue-500 flex items-center justify-center shadow-lg shadow-purple-500/30">
              <LionLogo className="w-8 h-8" />
            </div>
            <span className="text-3xl font-bold">
              <span className="text-white">lion</span>
              <span className="gradient-text">.ai</span>
            </span>
          </div>

          {/* Title */}
          <h1 className="text-3xl font-bold text-white mb-2">
            {step === 'email' && 'Build Full-Stack'}
            {step === 'pin' && 'Welcome Back'}
            {step === 'create_pin' && 'Secure Your Account'}
          </h1>
          <p className="text-lg gradient-text mb-8">
            {step === 'email' && 'Web & Mobile Apps in minutes'}
            {step === 'pin' && 'Enter your PIN to continue'}
            {step === 'create_pin' && 'Create a 4-digit PIN'}
          </p>

          {/* Success Message */}
          {successMessage && (
            <div className="mb-6 p-4 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              <span className="text-emerald-400">{successMessage}</span>
            </div>
          )}

          {/* Error Message */}
          {error && (
            <div className="mb-6 p-4 rounded-xl bg-red-500/20 border border-red-500/30 flex items-center gap-3">
              <ShieldAlert className="w-5 h-5 text-red-400" />
              <span className="text-red-400">{error}</span>
            </div>
          )}

          {/* Email Step */}
          {step === 'email' && (
            <form onSubmit={handleEmailSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-white/60 mb-2">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/30" />
                  <Input
                    type="email"
                    placeholder="your@email.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    disabled={isLoading}
                    className="pl-12 h-14 bg-white/5 border-white/20 text-white placeholder:text-white/30 focus:border-purple-500 focus:ring-purple-500/20"
                    data-testid="email-input"
                  />
                </div>
              </div>

              <Button
                type="submit"
                disabled={isLoading || !email}
                className="w-full h-14 bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 hover:opacity-90 text-white font-semibold text-lg"
                data-testid="continue-btn"
              >
                {isLoading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  'Continue'
                )}
              </Button>

              {/* Invite Only Notice */}
              <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                <p className="text-sm text-white/60 text-center">
                  <span className="text-purple-400 font-semibold">Invite Only</span> - 
                  New users need admin approval to access Lion AI.
                </p>
              </div>
            </form>
          )}

          {/* PIN Login Step */}
          {step === 'pin' && (
            <form onSubmit={handleLoginSubmit} className="space-y-6">
              <button
                type="button"
                onClick={goBack}
                className="flex items-center gap-2 text-white/60 hover:text-white transition-colors mb-4"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Back to email</span>
              </button>

              <div className="text-center mb-6">
                <p className="text-white/60">
                  Logged in as <span className="text-white font-semibold">{email}</span>
                </p>
                {isAdmin && (
                  <span className="inline-block mt-2 px-3 py-1 rounded-full bg-purple-500/20 text-purple-400 text-xs font-semibold">
                    Admin Account
                  </span>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-white/60 mb-4 text-center">
                  Enter your 4-digit PIN
                </label>
                <PinInputGroup
                  values={pin}
                  onChange={(idx, val) => handlePinChange(idx, val, false)}
                  onKeyDown={(idx, e) => handlePinKeyDown(idx, e, false)}
                  onPaste={(e) => handlePinPaste(e, false)}
                  refs={pinRefs}
                  disabled={isLoading}
                />
              </div>

              <Button
                type="submit"
                disabled={isLoading || pin.join('').length !== 4}
                className="w-full h-14 bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 hover:opacity-90 text-white font-semibold text-lg"
                data-testid="login-btn"
              >
                {isLoading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  'Login'
                )}
              </Button>
            </form>
          )}

          {/* Create PIN Step */}
          {step === 'create_pin' && (
            <form onSubmit={handleCreatePinSubmit} className="space-y-6">
              <button
                type="button"
                onClick={goBack}
                className="flex items-center gap-2 text-white/60 hover:text-white transition-colors mb-4"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Back to email</span>
              </button>

              <div className="text-center mb-6">
                <p className="text-white/60">
                  Creating account for <span className="text-white font-semibold">{email}</span>
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-white/60 mb-4 text-center">
                  Create a 4-digit PIN
                </label>
                <PinInputGroup
                  values={pin}
                  onChange={(idx, val) => handlePinChange(idx, val, false)}
                  onKeyDown={(idx, e) => handlePinKeyDown(idx, e, false)}
                  onPaste={(e) => handlePinPaste(e, false)}
                  refs={pinRefs}
                  disabled={isLoading}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-white/60 mb-4 text-center">
                  Confirm your PIN
                </label>
                <PinInputGroup
                  values={confirmPin}
                  onChange={(idx, val) => handlePinChange(idx, val, true)}
                  onKeyDown={(idx, e) => handlePinKeyDown(idx, e, true)}
                  onPaste={(e) => handlePinPaste(e, true)}
                  refs={confirmPinRefs}
                  disabled={isLoading}
                />
              </div>

              <Button
                type="submit"
                disabled={isLoading || pin.join('').length !== 4 || confirmPin.join('').length !== 4}
                className="w-full h-14 bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 hover:opacity-90 text-white font-semibold text-lg"
                data-testid="create-account-btn"
              >
                {isLoading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  'Create Account'
                )}
              </Button>

              <p className="text-xs text-white/40 text-center">
                Your PIN will be securely encrypted. Remember it to access your account.
              </p>
            </form>
          )}

          {/* Footer */}
          <p className="text-xs text-white/30 text-center mt-8">
            By continuing, you agree to our Terms of Service and Privacy Policy.
          </p>
        </div>
      </div>

      {/* Right Panel - Hero */}
      <div className="hidden lg:flex flex-1 items-center justify-center p-8 bg-gradient-to-br from-purple-900/20 via-transparent to-pink-900/20">
        <div className="max-w-lg text-center">
          <div className="inline-block px-4 py-2 rounded-full bg-gradient-to-r from-pink-500/20 to-purple-500/20 border border-purple-500/30 mb-8">
            <span className="text-sm font-medium gradient-text">Unlimited Power</span>
          </div>
          
          <div className="mb-8">
            <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-pink-500 via-purple-500 to-blue-500 flex items-center justify-center mx-auto shadow-2xl shadow-purple-500/30">
              <span className="text-4xl font-bold text-white">∞</span>
            </div>
          </div>
          
          <h2 className="text-2xl font-bold text-white mb-4">
            No credit limits. Build forever.
          </h2>
          <p className="text-white/50">
            Generate unlimited full-stack applications with AI. 
            No restrictions, no hidden costs.
          </p>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
