import React, { useState, useEffect } from 'react';
import { Crown, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '../ui/button';
import { mockAnnouncements } from '../../data/mock';

const AnnouncementCarousel = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % mockAnnouncements.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const goToPrevious = () => {
    setCurrentIndex((prev) => 
      prev === 0 ? mockAnnouncements.length - 1 : prev - 1
    );
  };

  const goToNext = () => {
    setCurrentIndex((prev) => (prev + 1) % mockAnnouncements.length);
  };

  const currentAnnouncement = mockAnnouncements[currentIndex];

  return (
    <div className="relative w-full max-w-md">
      <div className={`rounded-2xl overflow-hidden bg-gradient-to-br ${currentAnnouncement.bgGradient} p-8 shadow-2xl`}>
        {/* Content */}
        <div className="text-center text-white">
          <div className="mb-2">
            <span className="inline-block px-3 py-1 bg-white/20 backdrop-blur-sm rounded-full text-sm font-medium">
              {currentAnnouncement.title}
            </span>
          </div>
          
          <h2 className="text-6xl font-black mb-2">
            {currentAnnouncement.highlight}
          </h2>
          
          <p className="text-lg font-medium mb-2">
            {currentAnnouncement.subtitle}
          </p>
          
          <p className="text-sm opacity-90">
            {currentAnnouncement.description}
          </p>
        </div>

        {/* Decorative Elements */}
        <div className="absolute top-4 right-4">
          <Crown className="w-8 h-8 text-white/30" />
        </div>
        <div className="absolute bottom-4 left-4">
          <div className="w-12 h-12 rounded-full bg-white/10 backdrop-blur-sm" />
        </div>
        <div className="absolute top-1/2 right-8">
          <div className="w-6 h-6 rounded-full bg-white/20" />
        </div>
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-center gap-4 mt-6">
        <Button
          variant="ghost"
          size="icon"
          onClick={goToPrevious}
          className="text-stone-400 hover:text-amber-400 hover:bg-stone-800/50"
        >
          <ChevronLeft className="w-5 h-5" />
        </Button>

        <div className="flex items-center gap-2">
          {mockAnnouncements.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentIndex(index)}
              className={`h-2 rounded-full transition-all duration-300 ${
                index === currentIndex 
                  ? 'w-8 bg-amber-400' 
                  : 'w-2 bg-stone-600 hover:bg-stone-500'
              }`}
            />
          ))}
        </div>

        <Button
          variant="ghost"
          size="icon"
          onClick={goToNext}
          className="text-stone-400 hover:text-amber-400 hover:bg-stone-800/50"
        >
          <ChevronRight className="w-5 h-5" />
        </Button>
      </div>
    </div>
  );
};

export default AnnouncementCarousel;
