import React, { useState, useEffect } from 'react';
import Sidebar from '../layout/Sidebar';
import ChatArea from '../chat/ChatArea';
import AdminPanel from '../admin/AdminPanel';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const Dashboard = ({ onLogout, userId, userEmail, isAdmin, sessionToken }) => {
  const [chats, setChats] = useState([]);
  const [activeChat, setActiveChat] = useState(null);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [showAdminPanel, setShowAdminPanel] = useState(false);

  useEffect(() => {
    if (userId) {
      loadChats();
    }
  }, [userId]);

  const loadChats = async () => {
    try {
      const response = await axios.get(`${API}/chats?user_id=${userId}`);
      setChats(response.data);
    } catch (error) {
      console.error('Failed to load chats:', error);
    }
  };

  const handleNewChat = async () => {
    try {
      const response = await axios.post(`${API}/chats?user_id=${userId}`, {
        title: 'New Chat'
      });
      setChats(prev => [response.data, ...prev]);
      setActiveChat(response.data.id);
    } catch (error) {
      console.error('Failed to create chat:', error);
    }
  };

  const handleSelectChat = async (chatId) => {
    setActiveChat(chatId);
    try {
      const response = await axios.get(`${API}/chats/${chatId}/messages?user_id=${userId}`);
      setChats(prev => prev.map(chat => 
        chat.id === chatId ? { ...chat, messages: response.data } : chat
      ));
    } catch (error) {
      console.error('Failed to load messages:', error);
    }
  };

  const handleDeleteChat = async (chatId) => {
    // Confirm deletion
    if (!window.confirm('Are you sure you want to delete this chat? This action cannot be undone.')) {
      return;
    }

    try {
      const response = await axios.delete(`${API}/chats/${chatId}?user_id=${userId}`);
      if (response.data.success) {
        setChats(prev => prev.filter(chat => chat.id !== chatId));
        if (activeChat === chatId) {
          setActiveChat(null);
        }
      }
    } catch (error) {
      console.error('Failed to delete chat:', error);
    }
  };

  const handleRenameChat = async (chatId, newTitle) => {
    try {
      await axios.put(`${API}/chats/${chatId}?user_id=${userId}`, { title: newTitle });
      setChats(prev => prev.map(chat => 
        chat.id === chatId ? { ...chat, title: newTitle } : chat
      ));
    } catch (error) {
      console.error('Failed to rename chat:', error);
    }
  };

  const handleSendMessage = async (content, settings = {}) => {
    let currentChatId = activeChat;
    
    if (!currentChatId) {
      try {
        const response = await axios.post(`${API}/chats?user_id=${userId}`, {
          title: content.slice(0, 40) + (content.length > 40 ? '...' : '')
        });
        currentChatId = response.data.id;
        setChats(prev => [response.data, ...prev]);
        setActiveChat(currentChatId);
      } catch (error) {
        console.error('Failed to create chat:', error);
        return;
      }
    }

    const userMessage = {
      id: `msg_${Date.now()}`,
      role: 'user',
      content,
      timestamp: new Date().toISOString()
    };

    setChats(prev => prev.map(chat => {
      if (chat.id === currentChatId) {
        const updatedMessages = [...(chat.messages || []), userMessage];
        return {
          ...chat,
          title: chat.messages?.length === 0 ? content.slice(0, 40) + (content.length > 40 ? '...' : '') : chat.title,
          messages: updatedMessages
        };
      }
      return chat;
    }));

    setIsLoading(true);

    try {
      const response = await axios.post(`${API}/chats/${currentChatId}/messages?user_id=${userId}`, {
        content,
        session_settings: settings.sessionSettings || {},
        ultra_mode: settings.ultraMode || false
      });

      const aiMessage = response.data;
      
      setChats(prev => prev.map(chat => {
        if (chat.id === currentChatId) {
          return {
            ...chat,
            messages: [...(chat.messages || []), aiMessage]
          };
        }
        return chat;
      }));
    } catch (error) {
      console.error('Failed to send message:', error);
      
      // Show the actual error from the API
      const errorDetail = error.response?.data?.detail || error.message;
      
      const errorMessage = {
        id: `msg_${Date.now()}_error`,
        role: 'assistant',
        content: `Error: ${errorDetail}`,
        timestamp: new Date().toISOString()
      };
      
      setChats(prev => prev.map(chat => {
        if (chat.id === currentChatId) {
          return {
            ...chat,
            messages: [...(chat.messages || []), errorMessage]
          };
        }
        return chat;
      }));
    } finally {
      setIsLoading(false);
    }
  };

  const currentChat = chats.find(c => c.id === activeChat);

  // Show Admin Panel
  if (showAdminPanel && isAdmin) {
    return (
      <AdminPanel 
        adminEmail={userEmail} 
        onClose={() => setShowAdminPanel(false)} 
      />
    );
  }

  return (
    <div className="flex h-screen bg-[hsl(240,20%,4%)]">
      <Sidebar
        chats={chats}
        activeChat={activeChat}
        onSelectChat={handleSelectChat}
        onNewChat={handleNewChat}
        onDeleteChat={handleDeleteChat}
        onRenameChat={handleRenameChat}
        collapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
        userEmail={userEmail}
        onLogout={onLogout}
        isAdmin={isAdmin}
        onOpenAdminPanel={() => setShowAdminPanel(true)}
      />
      <ChatArea
        chat={currentChat}
        onSendMessage={handleSendMessage}
        isLoading={isLoading}
        userId={userId}
      />
    </div>
  );
};

export default Dashboard;
