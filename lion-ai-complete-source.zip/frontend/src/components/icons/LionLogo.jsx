import React from 'react';

const LionLogo = ({ className = "w-8 h-8", animated = false }) => {
  return (
    <svg 
      viewBox="0 0 100 100" 
      className={`${className} ${animated ? 'animate-pulse' : ''}`}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Mane - outer glow */}
      <defs>
        <linearGradient id="maneGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#ec4899" />
          <stop offset="50%" stopColor="#8b5cf6" />
          <stop offset="100%" stopColor="#3b82f6" />
        </linearGradient>
        <linearGradient id="faceGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#f472b6" />
          <stop offset="100%" stopColor="#a78bfa" />
        </linearGradient>
        <filter id="glow">
          <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
          <feMerge>
            <feMergeNode in="coloredBlur"/>
            <feMergeNode in="SourceGraphic"/>
          </feMerge>
        </filter>
      </defs>
      
      {/* Outer Mane */}
      <path 
        d="M50 5 L60 20 L80 15 L75 35 L95 40 L80 55 L90 75 L70 70 L60 90 L50 75 L40 90 L30 70 L10 75 L20 55 L5 40 L25 35 L20 15 L40 20 Z"
        fill="url(#maneGradient)"
        filter="url(#glow)"
      />
      
      {/* Inner face circle */}
      <circle 
        cx="50" 
        cy="50" 
        r="28" 
        fill="url(#faceGradient)"
      />
      
      {/* Eyes */}
      <ellipse cx="40" cy="45" rx="5" ry="6" fill="white" />
      <ellipse cx="60" cy="45" rx="5" ry="6" fill="white" />
      <circle cx="41" cy="46" r="3" fill="#1e1b4b" />
      <circle cx="61" cy="46" r="3" fill="#1e1b4b" />
      <circle cx="42" cy="45" r="1" fill="white" />
      <circle cx="62" cy="45" r="1" fill="white" />
      
      {/* Nose */}
      <path 
        d="M50 52 L46 58 L54 58 Z" 
        fill="#1e1b4b"
      />
      
      {/* Mouth */}
      <path 
        d="M50 58 Q50 65 44 62" 
        stroke="#1e1b4b" 
        strokeWidth="2" 
        fill="none"
        strokeLinecap="round"
      />
      <path 
        d="M50 58 Q50 65 56 62" 
        stroke="#1e1b4b" 
        strokeWidth="2" 
        fill="none"
        strokeLinecap="round"
      />
      
      {/* Whisker dots */}
      <circle cx="35" cy="55" r="1.5" fill="#1e1b4b" />
      <circle cx="32" cy="58" r="1.5" fill="#1e1b4b" />
      <circle cx="65" cy="55" r="1.5" fill="#1e1b4b" />
      <circle cx="68" cy="58" r="1.5" fill="#1e1b4b" />
    </svg>
  );
};

export default LionLogo;
