// Mock data for lion.ai application

export const mockUser = {
  id: "user_001",
  name: "Demo User",
  email: "demo@lion.ai",
  avatar: null,
  credits: "∞",
  plan: "Unlimited",
  createdAt: new Date().toISOString()
};

export const mockChats = [];

export const mockAnnouncements = [
  {
    id: 1,
    title: "Unlimited Power",
    subtitle: "Build anything, anytime",
    highlight: "∞",
    description: "No credit limits. Create as many apps as you want."
  },
  {
    id: 2,
    title: "AI-Powered",
    subtitle: "Smart code generation",
    highlight: "AI",
    description: "Advanced AI that writes, fixes, and optimizes code."
  },
  {
    id: 3,
    title: "Live Preview",
    subtitle: "See your app instantly",
    highlight: "LIVE",
    description: "Real-time preview as you build your application."
  }
];

export const codeExamples = {
  react: `import React from 'react';

function App() {
  return (
    <div className="app">
      <h1>Hello World</h1>
    </div>
  );
}

export default App;`,
  python: `from fastapi import FastAPI

app = FastAPI()

@app.get("/")
async def root():
    return {"message": "Hello World"}`
};
