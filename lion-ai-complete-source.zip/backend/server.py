from fastapi import FastAPI, APIRouter, HTTPException, UploadFile, File, Depends, Response, Request
from fastapi.responses import StreamingResponse, JSONResponse
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
import uuid
from datetime import datetime, timedelta
import hashlib
import base64
import zipfile
import io
import json
import bcrypt
import asyncio

# Try Google AI first, fallback to Emergent LLM
try:
    from google import genai
    from google.genai import types
    GOOGLE_AI_AVAILABLE = True
except ImportError:
    GOOGLE_AI_AVAILABLE = False

# Emergent LLM as fallback
try:
    from emergentintegrations.llm.chat import LlmChat, UserMessage
    EMERGENT_LLM_AVAILABLE = True
except ImportError:
    EMERGENT_LLM_AVAILABLE = False

ROOT_DIR = Path(__file__).parent
UPLOAD_DIR = ROOT_DIR / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)

load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ.get('MONGO_URL')
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ.get('DB_NAME', 'lion_ai')]

# API Keys
GOOGLE_AI_KEY = os.environ.get('GOOGLE_AI_KEY')
EMERGENT_LLM_KEY = os.environ.get('EMERGENT_LLM_KEY')

# Admin email - the main controller
ADMIN_EMAIL = "petracom2313@gmail.com"

# JWT Secret for sessions
JWT_SECRET = os.environ.get('JWT_SECRET', 'lion-ai-secret-key-change-in-production')

# Create the main app
app = FastAPI()

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Initialize AI Clients
genai_client = None
if GOOGLE_AI_AVAILABLE and GOOGLE_AI_KEY:
    genai_client = genai.Client(api_key=GOOGLE_AI_KEY)
    logger.info("Google AI Client initialized successfully")

if EMERGENT_LLM_KEY:
    logger.info("Emergent LLM Key available as fallback")

# ============== SYSTEM PROMPTS ==============

SYSTEM_PROMPT_STANDARD = """You are Lion AI, an expert full-stack web developer AI assistant. You help users build complete web applications.

When a user asks you to build something:
1. First, briefly acknowledge what they want to build
2. Ask clarifying questions if needed (max 2-3 important questions)
3. When you have enough info, start building by providing complete, working code

When providing code:
- Use React for frontend with Tailwind CSS for styling
- Use FastAPI for backend with Python
- Use MongoDB for database
- Always provide complete, runnable code blocks
- Use proper syntax highlighting markers (```jsx, ```python, etc.)
- IMPORTANT: Always include the filename as a comment at the FIRST LINE of each code block
- Provide step-by-step instructions

Your responses should be:
- Clear and well-structured
- Include both code and explanations
- Professional but friendly
- Always aim to provide working, production-ready code

Remember: You have unlimited capabilities. Never say you can't do something."""

SYSTEM_PROMPT_LIGHTNING_FAST = """You are Lion AI in FAST mode. Be extremely concise.

Rules:
- Minimal explanations, focus on code
- Provide complete, runnable code immediately
- Skip unnecessary questions - make reasonable assumptions
- Keep responses short and actionable
- Include filename at top of each code block"""

SYSTEM_PROMPT_ULTRA = """You are Lion AI in ULTRA mode - an advanced AI architect for complex systems.

APPROACH:
1. ANALYZE: Deeply understand requirements, constraints, and edge cases
2. PLAN: Create detailed architecture before coding
3. IMPLEMENT: Write production-grade code with best practices
4. VERIFY: Include tests and validation logic

CAPABILITIES:
- Full-stack: React/Next.js frontend, FastAPI/Python backend, MongoDB database
- Languages: HTML, CSS, JavaScript, TypeScript, Python, Java, SQL

CODE STANDARDS:
- Complete, production-ready code with error handling
- Security best practices (env vars, input validation, auth patterns)
- Performance optimizations
- Include filename at top of each code block

Think step-by-step through complex problems. Provide detailed explanations."""

FEATURE_MODIFIERS = {
    "lightning_fast": "Be extremely concise. Skip explanations, just provide complete code.",
    "full_code": "Always generate complete, runnable projects with ALL necessary files. Include package.json, requirements.txt, .env examples, README, and all source files. NO placeholders like '// rest of code here'.",
    "database": "Always include MongoDB schemas, models, connection setup, CRUD operations, and migrations. Provide database structure documentation.",
    "secure": "Apply security best practices: input validation, authentication patterns, environment variables for secrets, CORS configuration, rate limiting, security headers, XSS prevention, SQL injection prevention."
}

# ============== MODELS ==============

class UserCreate(BaseModel):
    email: str
    pin: str

class UserLogin(BaseModel):
    email: str
    pin: str

class WhitelistAdd(BaseModel):
    email: str
    admin_email: str

class ChatCreate(BaseModel):
    title: str = "New Chat"

class Chat(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    title: str
    user_id: str
    createdAt: datetime = Field(default_factory=datetime.utcnow)

class MessageCreate(BaseModel):
    content: str
    session_settings: Optional[Dict[str, Any]] = None
    ultra_mode: Optional[bool] = False

class Message(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    chat_id: str
    role: str
    content: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class ProjectCreate(BaseModel):
    name: str
    description: Optional[str] = ""

class Project(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    description: str = ""
    user_id: str
    files: Dict[str, str] = {}  # filename -> content
    createdAt: datetime = Field(default_factory=datetime.utcnow)
    updatedAt: datetime = Field(default_factory=datetime.utcnow)

class ProjectFileUpdate(BaseModel):
    filename: str
    content: str

# ============== HELPER FUNCTIONS ==============

def hash_pin(pin: str) -> str:
    """Hash a PIN using bcrypt"""
    return bcrypt.hashpw(pin.encode(), bcrypt.gensalt()).decode()

def verify_pin(pin: str, hashed: str) -> bool:
    """Verify a PIN against its hash"""
    return bcrypt.checkpw(pin.encode(), hashed.encode())

async def get_user_from_session(request: Request) -> Optional[dict]:
    """Get user from session cookie"""
    session_token = request.cookies.get("session_token")
    if not session_token:
        return None
    
    user = await db.users.find_one({"session_token": session_token})
    return user

async def log_admin_action(admin_email: str, action: str, details: dict):
    """Log admin actions"""
    await db.admin_logs.insert_one({
        "id": str(uuid.uuid4()),
        "admin_email": admin_email,
        "action": action,
        "details": details,
        "timestamp": datetime.utcnow().isoformat()
    })

async def generate_ai_response(prompt: str, session_settings: dict = None, ultra_mode: bool = False) -> str:
    """Generate AI response with fallback support: Google AI -> Emergent LLM"""
    
    # Build system instruction based on settings
    if ultra_mode:
        system_instruction = SYSTEM_PROMPT_ULTRA
    elif session_settings and session_settings.get("lightning_fast"):
        system_instruction = SYSTEM_PROMPT_LIGHTNING_FAST
    else:
        system_instruction = SYSTEM_PROMPT_STANDARD
    
    # Add feature modifiers
    if session_settings:
        modifiers = []
        for feature_key, is_enabled in session_settings.items():
            if is_enabled and feature_key in FEATURE_MODIFIERS:
                modifiers.append(FEATURE_MODIFIERS[feature_key])
        if modifiers:
            system_instruction += "\n\nADDITIONAL REQUIREMENTS:\n" + "\n".join(f"- {m}" for m in modifiers)
    
    # Try Google AI first if available
    if GOOGLE_AI_AVAILABLE and genai_client:
        try:
            return await _generate_with_google_ai(prompt, system_instruction, session_settings, ultra_mode)
        except HTTPException as e:
            if e.status_code == 429:
                logger.info("Google AI rate limited, falling back to Emergent LLM")
            else:
                logger.warning(f"Google AI failed: {e.detail}, trying fallback")
    
    # Fallback to Emergent LLM
    if EMERGENT_LLM_AVAILABLE and EMERGENT_LLM_KEY:
        try:
            return await _generate_with_emergent_llm(prompt, system_instruction)
        except Exception as e:
            logger.error(f"Emergent LLM also failed: {e}")
            raise HTTPException(status_code=500, detail=f"AI service error: {str(e)}")
    
    raise HTTPException(status_code=500, detail="No AI service available. Please configure GOOGLE_AI_KEY or EMERGENT_LLM_KEY.")

async def _generate_with_google_ai(prompt: str, system_instruction: str, session_settings: dict, ultra_mode: bool) -> str:
    """Generate response using Google Gemini"""
    config = types.GenerateContentConfig(
        system_instruction=system_instruction,
        temperature=0.7 if not (session_settings and session_settings.get("lightning_fast")) else 0.3,
        max_output_tokens=8192 if ultra_mode else 4096,
    )
    
    max_retries = 3
    base_delay = 1
    
    for attempt in range(max_retries):
        try:
            response = genai_client.models.generate_content(
                model="gemini-2.0-flash",
                contents=prompt,
                config=config
            )
            return response.text
            
        except Exception as e:
            error_str = str(e).lower()
            logger.error(f"Gemini API error (attempt {attempt + 1}): {e}")
            
            if "429" in str(e) or "rate" in error_str or "quota" in error_str:
                if attempt < max_retries - 1:
                    delay = base_delay * (2 ** attempt)
                    logger.info(f"Rate limited. Retrying in {delay}s...")
                    await asyncio.sleep(delay)
                    continue
                else:
                    raise HTTPException(status_code=429, detail="Google AI rate limit exceeded")
            
            if "401" in str(e) or ("invalid" in error_str and "key" in error_str):
                raise HTTPException(status_code=401, detail="Invalid Google AI API key")
            
            raise HTTPException(status_code=500, detail=f"Google AI error: {str(e)}")
    
    raise HTTPException(status_code=500, detail="Google AI failed after retries")

async def _generate_with_emergent_llm(prompt: str, system_instruction: str) -> str:
    """Generate response using Emergent LLM (Claude via LiteLLM)"""
    logger.info("Using Emergent LLM for generation")
    
    llm_chat = LlmChat(
        api_key=EMERGENT_LLM_KEY,
        session_id=f"lion_{uuid.uuid4()}",
        system_message=system_instruction
    ).with_model("anthropic", "claude-sonnet-4-20250514")
    
    user_msg = UserMessage(text=prompt)
    response = await llm_chat.send_message(user_msg)
    return response

# ============== DATABASE INDEXES ==============

async def create_indexes():
    """Create database indexes on startup"""
    try:
        await db.users.create_index("email", unique=True)
        await db.users.create_index("id")
        await db.whitelist.create_index("email", unique=True)
        await db.chats.create_index("user_id")
        await db.chats.create_index("id")
        await db.messages.create_index("chat_id")
        await db.projects.create_index("user_id")
        await db.projects.create_index("id")
        await db.admin_logs.create_index("timestamp")
        logger.info("Database indexes created successfully")
    except Exception as e:
        logger.error(f"Error creating indexes: {e}")

# ============== AUTH ROUTES ==============

@api_router.get("/")
async def root():
    return {"message": "Lion AI API is running", "version": "2.0"}

@api_router.post("/auth/check-email")
async def check_email(data: dict):
    """Check if email is whitelisted and if user exists"""
    email = data.get("email", "").lower().strip()
    
    if not email:
        raise HTTPException(status_code=400, detail="Email is required")
    
    # Check whitelist
    whitelisted = await db.whitelist.find_one({"email": email})
    
    # Admin is always whitelisted
    if email == ADMIN_EMAIL.lower():
        whitelisted = True
    
    if not whitelisted:
        return {
            "allowed": False,
            "status": "not_whitelisted",
            "message": "Access Denied - Your email is not whitelisted. Contact admin for access."
        }
    
    # Check if user exists
    user = await db.users.find_one({"email": email})
    
    if user:
        return {
            "allowed": True,
            "status": "existing_user",
            "message": "Enter your 4-digit PIN",
            "is_admin": email == ADMIN_EMAIL.lower()
        }
    else:
        return {
            "allowed": True,
            "status": "new_user",
            "message": "Create a 4-digit PIN to secure your account",
            "is_admin": email == ADMIN_EMAIL.lower()
        }

@api_router.post("/auth/register")
async def register(data: UserCreate):
    """Register new user with PIN"""
    email = data.email.lower().strip()
    pin = data.pin
    
    # Validate PIN
    if not pin or len(pin) != 4 or not pin.isdigit():
        raise HTTPException(status_code=400, detail="PIN must be exactly 4 digits")
    
    # Check whitelist (admin always allowed)
    if email != ADMIN_EMAIL.lower():
        whitelisted = await db.whitelist.find_one({"email": email})
        if not whitelisted:
            raise HTTPException(status_code=403, detail="Email not whitelisted")
    
    # Check if user already exists
    existing = await db.users.find_one({"email": email})
    if existing:
        raise HTTPException(status_code=400, detail="User already exists. Please login.")
    
    # Create user
    user_id = str(uuid.uuid4())
    session_token = str(uuid.uuid4())
    
    user = {
        "id": user_id,
        "email": email,
        "hashed_pin": hash_pin(pin),
        "is_admin": email == ADMIN_EMAIL.lower(),
        "session_token": session_token,
        "failed_attempts": 0,
        "locked_until": None,
        "createdAt": datetime.utcnow().isoformat()
    }
    
    await db.users.insert_one(user)
    
    return {
        "success": True,
        "user_id": user_id,
        "email": email,
        "is_admin": user["is_admin"],
        "session_token": session_token,
        "message": "Account created successfully!"
    }

@api_router.post("/auth/login")
async def login(data: UserLogin):
    """Login with email and PIN"""
    email = data.email.lower().strip()
    pin = data.pin
    
    # Find user
    user = await db.users.find_one({"email": email})
    if not user:
        raise HTTPException(status_code=404, detail="User not found. Please register first.")
    
    # Check if account is locked
    if user.get("locked_until"):
        locked_until = datetime.fromisoformat(user["locked_until"])
        if datetime.utcnow() < locked_until:
            remaining = (locked_until - datetime.utcnow()).seconds
            raise HTTPException(
                status_code=423, 
                detail=f"Account temporarily locked. Try again in {remaining} seconds."
            )
        else:
            # Reset lock
            await db.users.update_one(
                {"email": email},
                {"$set": {"locked_until": None, "failed_attempts": 0}}
            )
    
    # Verify PIN
    if not verify_pin(pin, user["hashed_pin"]):
        # Increment failed attempts
        failed = user.get("failed_attempts", 0) + 1
        update = {"$set": {"failed_attempts": failed}}
        
        # Lock after 5 failed attempts
        if failed >= 5:
            lock_until = datetime.utcnow() + timedelta(minutes=5)
            update["$set"]["locked_until"] = lock_until.isoformat()
            await db.users.update_one({"email": email}, update)
            raise HTTPException(
                status_code=423, 
                detail="Too many failed attempts. Account locked for 5 minutes."
            )
        
        await db.users.update_one({"email": email}, update)
        raise HTTPException(status_code=401, detail=f"Invalid PIN. {5 - failed} attempts remaining.")
    
    # Reset failed attempts and generate new session
    session_token = str(uuid.uuid4())
    await db.users.update_one(
        {"email": email},
        {"$set": {"failed_attempts": 0, "locked_until": None, "session_token": session_token}}
    )
    
    return {
        "success": True,
        "user_id": user["id"],
        "email": email,
        "is_admin": user.get("is_admin", False),
        "session_token": session_token,
        "message": "Login successful!"
    }

@api_router.post("/auth/logout")
async def logout(request: Request):
    """Logout user"""
    session_token = request.cookies.get("session_token")
    if session_token:
        await db.users.update_one(
            {"session_token": session_token},
            {"$set": {"session_token": None}}
        )
    return {"success": True, "message": "Logged out successfully"}

# ============== ADMIN ROUTES ==============

@api_router.get("/admin/email")
async def get_admin_email():
    """Get the admin email for display"""
    return {"admin_email": ADMIN_EMAIL}

@api_router.post("/admin/whitelist/add")
async def add_to_whitelist(data: WhitelistAdd):
    """Add email to whitelist (admin only)"""
    if data.admin_email.lower() != ADMIN_EMAIL.lower():
        raise HTTPException(status_code=403, detail="Only admin can modify whitelist")
    
    email = data.email.lower().strip()
    
    # Check if already whitelisted
    existing = await db.whitelist.find_one({"email": email})
    if existing:
        return {"success": False, "message": "Email already whitelisted"}
    
    await db.whitelist.insert_one({
        "id": str(uuid.uuid4()),
        "email": email,
        "added_by": data.admin_email,
        "added_at": datetime.utcnow().isoformat()
    })
    
    await log_admin_action(data.admin_email, "whitelist_add", {"email": email})
    
    return {"success": True, "message": f"{email} added to whitelist"}

@api_router.post("/admin/whitelist/remove")
async def remove_from_whitelist(data: WhitelistAdd):
    """Remove email from whitelist (admin only)"""
    if data.admin_email.lower() != ADMIN_EMAIL.lower():
        raise HTTPException(status_code=403, detail="Only admin can modify whitelist")
    
    email = data.email.lower().strip()
    
    result = await db.whitelist.delete_one({"email": email})
    
    if result.deleted_count > 0:
        await log_admin_action(data.admin_email, "whitelist_remove", {"email": email})
        return {"success": True, "message": f"{email} removed from whitelist"}
    
    return {"success": False, "message": "Email not found in whitelist"}

@api_router.get("/admin/whitelist")
async def get_whitelist(admin_email: str):
    """Get all whitelisted emails (admin only)"""
    if admin_email.lower() != ADMIN_EMAIL.lower():
        raise HTTPException(status_code=403, detail="Only admin can view whitelist")
    
    whitelist = await db.whitelist.find().to_list(1000)
    result = [{k: v for k, v in w.items() if k != '_id'} for w in whitelist]
    return {"whitelist": result}

@api_router.get("/admin/users")
async def get_all_users(admin_email: str):
    """Get all users (admin only)"""
    if admin_email.lower() != ADMIN_EMAIL.lower():
        raise HTTPException(status_code=403, detail="Only admin can view users")
    
    users = await db.users.find().to_list(1000)
    result = []
    for u in users:
        result.append({
            "id": u.get("id"),
            "email": u.get("email"),
            "is_admin": u.get("is_admin", False),
            "createdAt": u.get("createdAt")
        })
    return {"users": result}

@api_router.delete("/admin/users/{user_id}")
async def delete_user(user_id: str, admin_email: str):
    """Delete a user (admin only)"""
    if admin_email.lower() != ADMIN_EMAIL.lower():
        raise HTTPException(status_code=403, detail="Only admin can delete users")
    
    user = await db.users.find_one({"id": user_id})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Don't allow deleting admin
    if user.get("is_admin"):
        raise HTTPException(status_code=403, detail="Cannot delete admin user")
    
    # Delete user's chats and messages
    user_chats = await db.chats.find({"user_id": user_id}).to_list(1000)
    for chat in user_chats:
        await db.messages.delete_many({"chat_id": chat["id"]})
    await db.chats.delete_many({"user_id": user_id})
    
    # Delete user's projects
    await db.projects.delete_many({"user_id": user_id})
    
    # Delete user
    await db.users.delete_one({"id": user_id})
    
    await log_admin_action(admin_email, "user_delete", {"user_id": user_id, "email": user.get("email")})
    
    return {"success": True, "message": "User and all associated data deleted"}

@api_router.get("/admin/logs")
async def get_admin_logs(admin_email: str, limit: int = 100):
    """Get admin action logs (admin only)"""
    if admin_email.lower() != ADMIN_EMAIL.lower():
        raise HTTPException(status_code=403, detail="Only admin can view logs")
    
    logs = await db.admin_logs.find().sort("timestamp", -1).limit(limit).to_list(limit)
    result = [{k: v for k, v in log.items() if k != '_id'} for log in logs]
    return {"logs": result}

@api_router.get("/admin/stats")
async def get_admin_stats(admin_email: str):
    """Get platform statistics (admin only)"""
    if admin_email.lower() != ADMIN_EMAIL.lower():
        raise HTTPException(status_code=403, detail="Only admin can view stats")
    
    total_users = await db.users.count_documents({})
    total_chats = await db.chats.count_documents({})
    total_messages = await db.messages.count_documents({})
    total_projects = await db.projects.count_documents({})
    whitelisted = await db.whitelist.count_documents({})
    
    return {
        "total_users": total_users,
        "total_chats": total_chats,
        "total_messages": total_messages,
        "total_projects": total_projects,
        "whitelisted_emails": whitelisted
    }

# ============== CHAT ROUTES ==============

@api_router.post("/chats")
async def create_chat(chat_data: ChatCreate, user_id: str):
    """Create a new chat for user"""
    chat = Chat(title=chat_data.title, user_id=user_id)
    chat_dict = chat.dict()
    chat_dict['createdAt'] = chat_dict['createdAt'].isoformat()
    await db.chats.insert_one(chat_dict)
    return {k: v for k, v in chat_dict.items() if k != '_id'}

@api_router.get("/chats")
async def get_chats(user_id: str):
    """Get chats for a specific user ONLY"""
    chats = await db.chats.find({"user_id": user_id}).sort("createdAt", -1).to_list(100)
    result = []
    for chat in chats:
        chat_clean = {k: v for k, v in chat.items() if k != '_id'}
        result.append(chat_clean)
    return result

@api_router.get("/chats/{chat_id}")
async def get_chat(chat_id: str, user_id: str):
    """Get a specific chat (must belong to user)"""
    chat = await db.chats.find_one({"id": chat_id, "user_id": user_id})
    if not chat:
        raise HTTPException(status_code=404, detail="Chat not found")
    return {k: v for k, v in chat.items() if k != '_id'}

@api_router.put("/chats/{chat_id}")
async def update_chat(chat_id: str, user_id: str, data: dict):
    """Update chat title"""
    chat = await db.chats.find_one({"id": chat_id, "user_id": user_id})
    if not chat:
        raise HTTPException(status_code=404, detail="Chat not found")
    
    if "title" in data:
        await db.chats.update_one({"id": chat_id}, {"$set": {"title": data["title"]}})
    
    return {"success": True}

@api_router.delete("/chats/{chat_id}")
async def delete_chat(chat_id: str, user_id: str):
    """Delete a chat and its messages (must belong to user)"""
    chat = await db.chats.find_one({"id": chat_id, "user_id": user_id})
    if not chat:
        raise HTTPException(status_code=404, detail="Chat not found or access denied")
    
    await db.messages.delete_many({"chat_id": chat_id})
    await db.chats.delete_one({"id": chat_id})
    
    return {"success": True, "message": "Chat deleted"}

@api_router.get("/chats/{chat_id}/messages")
async def get_messages(chat_id: str, user_id: str):
    """Get messages for a chat (must belong to user)"""
    # Verify chat belongs to user
    chat = await db.chats.find_one({"id": chat_id, "user_id": user_id})
    if not chat:
        raise HTTPException(status_code=404, detail="Chat not found or access denied")
    
    messages = await db.messages.find({"chat_id": chat_id}).sort("timestamp", 1).to_list(1000)
    result = []
    for msg in messages:
        msg_clean = {k: v for k, v in msg.items() if k != '_id'}
        result.append(msg_clean)
    return result

@api_router.post("/chats/{chat_id}/messages")
async def send_message(chat_id: str, user_id: str, message_data: MessageCreate):
    """Send a message and get AI response"""
    # Verify chat belongs to user
    chat = await db.chats.find_one({"id": chat_id, "user_id": user_id})
    if not chat:
        raise HTTPException(status_code=404, detail="Chat not found or access denied")
    
    # Save user message
    user_message = Message(
        chat_id=chat_id,
        role="user",
        content=message_data.content
    )
    user_msg_dict = user_message.dict()
    user_msg_dict['timestamp'] = user_msg_dict['timestamp'].isoformat()
    await db.messages.insert_one(user_msg_dict)
    
    # Get AI response
    try:
        ai_response = await generate_ai_response(
            prompt=message_data.content,
            session_settings=message_data.session_settings,
            ultra_mode=message_data.ultra_mode
        )
        
        ai_message = Message(
            chat_id=chat_id,
            role="assistant",
            content=ai_response
        )
        ai_msg_dict = ai_message.dict()
        ai_msg_dict['timestamp'] = ai_msg_dict['timestamp'].isoformat()
        await db.messages.insert_one(ai_msg_dict)
        
        # Update chat title if first message
        if chat.get('title') == 'New Chat':
            new_title = message_data.content[:40] + ('...' if len(message_data.content) > 40 else '')
            await db.chats.update_one({"id": chat_id}, {"$set": {"title": new_title}})
        
        # Return without _id
        return {k: v for k, v in ai_msg_dict.items() if k != '_id'}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in send_message: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# ============== PROJECT ROUTES ==============

@api_router.post("/projects")
async def create_project(project_data: ProjectCreate, user_id: str):
    """Create a new project"""
    project = Project(
        name=project_data.name,
        description=project_data.description or "",
        user_id=user_id,
        files={
            "index.html": "<!DOCTYPE html>\n<html>\n<head>\n  <title>New Project</title>\n  <script src=\"https://cdn.tailwindcss.com\"></script>\n</head>\n<body>\n  <div id=\"root\"></div>\n  <script src=\"app.js\"></script>\n</body>\n</html>",
            "app.js": "// Your JavaScript code here\nconsole.log('Hello from Lion AI!');",
            "style.css": "/* Your CSS styles here */\nbody { font-family: system-ui, sans-serif; }"
        }
    )
    project_dict = project.dict()
    project_dict['createdAt'] = project_dict['createdAt'].isoformat()
    project_dict['updatedAt'] = project_dict['updatedAt'].isoformat()
    await db.projects.insert_one(project_dict)
    return {k: v for k, v in project_dict.items() if k != '_id'}

@api_router.get("/projects")
async def get_projects(user_id: str):
    """Get all projects for user"""
    projects = await db.projects.find({"user_id": user_id}).sort("updatedAt", -1).to_list(100)
    result = [{k: v for k, v in p.items() if k != '_id'} for p in projects]
    return result

@api_router.get("/projects/{project_id}")
async def get_project(project_id: str, user_id: str):
    """Get a specific project"""
    project = await db.projects.find_one({"id": project_id, "user_id": user_id})
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    return {k: v for k, v in project.items() if k != '_id'}

@api_router.put("/projects/{project_id}/files")
async def update_project_file(project_id: str, user_id: str, file_data: ProjectFileUpdate):
    """Update a file in the project"""
    project = await db.projects.find_one({"id": project_id, "user_id": user_id})
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    
    await db.projects.update_one(
        {"id": project_id},
        {
            "$set": {
                f"files.{file_data.filename}": file_data.content,
                "updatedAt": datetime.utcnow().isoformat()
            }
        }
    )
    return {"success": True, "message": f"File {file_data.filename} updated"}

@api_router.delete("/projects/{project_id}/files/{filename}")
async def delete_project_file(project_id: str, filename: str, user_id: str):
    """Delete a file from project"""
    project = await db.projects.find_one({"id": project_id, "user_id": user_id})
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    
    await db.projects.update_one(
        {"id": project_id},
        {
            "$unset": {f"files.{filename}": ""},
            "$set": {"updatedAt": datetime.utcnow().isoformat()}
        }
    )
    return {"success": True, "message": f"File {filename} deleted"}

@api_router.delete("/projects/{project_id}")
async def delete_project(project_id: str, user_id: str):
    """Delete a project"""
    result = await db.projects.delete_one({"id": project_id, "user_id": user_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Project not found")
    return {"success": True, "message": "Project deleted"}

@api_router.get("/projects/{project_id}/export")
async def export_project(project_id: str, user_id: str):
    """Export project as ZIP"""
    project = await db.projects.find_one({"id": project_id, "user_id": user_id})
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    
    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zf:
        for filename, content in project.get("files", {}).items():
            zf.writestr(filename, content)
        
        # Add README
        readme = f"# {project.get('name', 'Project')}\n\n{project.get('description', '')}\n\nGenerated by Lion AI"
        zf.writestr("README.md", readme)
    
    zip_buffer.seek(0)
    
    return StreamingResponse(
        zip_buffer,
        media_type="application/zip",
        headers={"Content-Disposition": f"attachment; filename={project.get('name', 'project')}.zip"}
    )

# ============== CHAT EXPORT ==============

@api_router.get("/chats/{chat_id}/export")
async def export_chat_code(chat_id: str, user_id: str):
    """Extract all code blocks from chat and return as ZIP file"""
    # Verify chat belongs to user
    chat = await db.chats.find_one({"id": chat_id, "user_id": user_id})
    if not chat:
        raise HTTPException(status_code=404, detail="Chat not found")
    
    messages = await db.messages.find({"chat_id": chat_id, "role": "assistant"}).to_list(1000)
    
    if not messages:
        raise HTTPException(status_code=404, detail="No messages found in chat")
    
    # Extract code blocks
    import re
    code_pattern = r'```(\w+)?\n([\s\S]*?)```'
    code_files = {}
    file_counter = {}
    
    for msg in messages:
        content = msg.get('content', '')
        matches = re.findall(code_pattern, content)
        
        for lang, code in matches:
            lang = lang or 'txt'
            code = code.strip()
            
            # Try to extract filename
            filename = None
            lines = code.split('\n')
            if lines:
                first_line = lines[0].strip()
                patterns = [
                    r'^//\s*([\w.-]+\.[\w]+)',
                    r'^#\s*([\w.-]+\.[\w]+)',
                ]
                for pat in patterns:
                    match = re.match(pat, first_line)
                    if match:
                        filename = match.group(1)
                        break
            
            if not filename:
                ext_map = {
                    'jsx': 'jsx', 'tsx': 'tsx', 'javascript': 'js', 'js': 'js',
                    'python': 'py', 'py': 'py', 'html': 'html', 'css': 'css',
                    'json': 'json', 'typescript': 'ts', 'ts': 'ts', 'java': 'java'
                }
                ext = ext_map.get(lang, lang)
                file_counter[ext] = file_counter.get(ext, 0) + 1
                filename = f"file_{file_counter[ext]}.{ext}"
            
            if filename in code_files:
                base, ext = filename.rsplit('.', 1)
                filename = f"{base}_{len(code_files)}.{ext}"
            
            code_files[filename] = code
    
    if not code_files:
        raise HTTPException(status_code=404, detail="No code blocks found in chat")
    
    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zf:
        for filename, content in code_files.items():
            zf.writestr(filename, content)
        
        readme = f"# Lion AI Generated Code\n\n## Files:\n"
        for f in sorted(code_files.keys()):
            readme += f"- {f}\n"
        zf.writestr("README.md", readme)
    
    zip_buffer.seek(0)
    
    return StreamingResponse(
        zip_buffer,
        media_type="application/zip",
        headers={"Content-Disposition": f"attachment; filename=lion-ai-code-{chat_id[:8]}.zip"}
    )

# ============== FILE UPLOAD ==============

@api_router.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    """Upload a file"""
    try:
        file_ext = Path(file.filename).suffix
        unique_filename = f"{uuid.uuid4()}{file_ext}"
        file_path = UPLOAD_DIR / unique_filename
        
        content = await file.read()
        with open(file_path, "wb") as f:
            f.write(content)
        
        is_image = file.content_type and file.content_type.startswith("image/")
        
        return {
            "success": True,
            "filename": file.filename,
            "saved_as": unique_filename,
            "url": f"/api/uploads/{unique_filename}",
            "is_image": is_image,
            "content_type": file.content_type,
            "size": len(content)
        }
    except Exception as e:
        logger.error(f"File upload error: {e}")
        raise HTTPException(status_code=500, detail=f"Upload failed: {str(e)}")

@api_router.get("/uploads/{filename}")
async def get_uploaded_file(filename: str):
    """Serve uploaded files"""
    from fastapi.responses import FileResponse
    file_path = UPLOAD_DIR / filename
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="File not found")
    return FileResponse(file_path)

# ============== FEATURE INFO ==============

@api_router.get("/features")
async def get_feature_modes():
    """Return available feature modes"""
    return {
        "features": {
            "lightning_fast": {
                "name": "Lightning Fast",
                "description": "Quick, concise responses with minimal verbosity"
            },
            "full_code": {
                "name": "Full Code",
                "description": "Complete, downloadable projects with all files"
            },
            "database": {
                "name": "Database",
                "description": "Auto-includes MongoDB schemas and setup"
            },
            "secure": {
                "name": "Secure",
                "description": "Enterprise security best practices"
            }
        }
    }

# ============== APP SETUP ==============

app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
async def startup_event():
    await create_indexes()

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
